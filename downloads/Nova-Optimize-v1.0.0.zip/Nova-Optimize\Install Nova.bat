@echo off
setlocal
title Nova Optimize - Setup
cd /d "%~dp0"

echo.
echo   ========================================================
echo     Nova Optimize v1.0.0 - Local Setup
echo     Free, local-first Windows 10/11 gaming performance
echo   ========================================================
echo.
echo   NOTICE: This software is provided "AS IS", without warranty
echo   of any kind under the MIT License. You use it at your own risk.
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo   [!] Node.js 18+ was not found on your PATH.
  echo   Attempting to check if winget can install Node.js LTS...
  where winget >nul 2>nul
  if not errorlevel 1 (
    set /p INSTALL_NODE="  Install Node.js LTS now via Windows Package Manager (winget)? [Y/N]: "
    if /i "%INSTALL_NODE%"=="Y" (
      winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
    )
  ) else (
    echo   Please install Node.js 18 LTS or newer from https://nodejs.org/
  )
)

echo.
echo   Creating Desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create Shortcut.ps1"
if errorlevel 1 (
  echo   [!] Could not create Desktop shortcut automatically.
  echo   You can still launch Nova anytime using "Start Nova.bat".
) else (
  echo   [OK] Desktop shortcut created.
)

echo.
set /p LAUNCH_NOW="  Launch Nova Optimize now? [Y/N] (default Y): "
if "%LAUNCH_NOW%"=="" set LAUNCH_NOW=Y
if /i "%LAUNCH_NOW%"=="Y" (
  start "" wscript.exe "%~dp0NovaOptimize.vbs"
  echo.
  echo   Nova Optimize is starting in its own window...
)

echo.
pause
exit /b 0

