Option Explicit

' Nova Optimize silent launcher.
' Starts the local server without a console window, then Nova opens its own
' app window. Use "Start Nova.bat" instead when you want to see server errors.

Dim fso, shell, baseDir, serverPath, nodePath, command
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

baseDir = fso.GetParentFolderName(WScript.ScriptFullName)
serverPath = fso.BuildPath(baseDir, "server\server.js")

If Not fso.FileExists(serverPath) Then
  MsgBox "Nova could not find server\server.js." & vbCrLf & vbCrLf & _
    "Keep NovaOptimize.vbs inside the Nova Optimize folder.", _
    vbCritical, "Nova Optimize"
  WScript.Quit 1
End If

nodePath = FindNode()
If nodePath = "" Then
  MsgBox "Nova needs Node.js 18 or newer." & vbCrLf & vbCrLf & _
    "Install the LTS version from https://nodejs.org/ and run this file again.", _
    vbCritical, "Nova Optimize"
  WScript.Quit 1
End If

shell.CurrentDirectory = baseDir
command = """" & nodePath & """ --max-old-space-size=96 """ & serverPath & """"
shell.Run command, 0, False

Function FindNode()
  Dim exec, line, candidates, candidate
  On Error Resume Next
  Set exec = shell.Exec("cmd /c where node.exe")
  If Err.Number = 0 Then
    Do While Not exec.StdOut.AtEndOfStream
      line = Trim(exec.StdOut.ReadLine())
      If Len(line) > 0 And fso.FileExists(line) Then
        FindNode = line
        Exit Function
      End If
    Loop
  End If
  Err.Clear
  On Error GoTo 0

  candidates = Array( _
    shell.ExpandEnvironmentStrings("%ProgramFiles%\nodejs\node.exe"), _
    shell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs\nodejs\node.exe"), _
    shell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\nodejs\node.exe"))
  For Each candidate In candidates
    If fso.FileExists(candidate) Then
      FindNode = candidate
      Exit Function
    End If
  Next
  FindNode = ""
End Function
