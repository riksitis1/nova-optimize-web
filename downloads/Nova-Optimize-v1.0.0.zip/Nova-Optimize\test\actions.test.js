'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { actions, getAction, getPublicActions } = require('../server/lib/actions');
const { makeSnapshot } = require('./fixtures');

function fakePs(handler) {
  const calls = [];
  const ps = async (op, args = {}) => {
    calls.push({ op, args });
    return handler(op, args, calls);
  };
  return { ps, calls };
}

test('every action is serializable and has the expected public shape', () => {
  const publicActions = getPublicActions(makeSnapshot(), { 'game-mode': new Date().toISOString() });
  assert.equal(publicActions.length, actions.length);
  assert.equal(new Set(publicActions.map((action) => action.id)).size, actions.length);
  for (const action of publicActions) {
    assert.ok(action.id && action.name && action.description, action.id);
    assert.ok(['low', 'medium', 'high'].includes(action.impact), action.id);
    assert.ok(['safe', 'caution', 'advanced'].includes(action.risk), action.id);
    assert.equal(typeof action.applicable, 'boolean');
    assert.equal(typeof action.optimized, 'boolean');
    assert.equal(typeof action.currentValue, 'string', action.id);
    assert.ok(action.currentValue.length > 0, action.id);
  }
  assert.equal(publicActions.find((action) => action.id === 'game-mode').appliedByNova, true);
  assert.equal(publicActions.find((action) => action.id === 'hags').requiresAdmin, true);
});

test('getAction resolves known ids and rejects unknown ids', () => {
  assert.equal(getAction('game-mode').id, 'game-mode');
  assert.equal(getAction('nope'), null);
});

test('registry actions back up every value before writing', async () => {
  const action = getAction('game-mode');
  const { ps, calls } = fakePs((op, args) => {
    if (op === 'registry.read') {
      return args.entries.map((entry) => ({ ...entry, exists: false, kind: 'DWord', value: null }));
    }
    if (op === 'registry.apply') return args.operations.map((operation) => ({ ok: true, name: operation.name }));
    throw new Error(`unexpected op ${op}`);
  });

  const backup = await action.apply({ ps, snapshot: makeSnapshot(), admin: false });
  assert.equal(backup.kind, 'registry');
  assert.equal(backup.entries.length, 2);
  assert.equal(calls[0].op, 'registry.read');
  assert.deepEqual(calls[0].args.entries.map((entry) => entry.name), ['AutoGameModeEnabled', 'AllowAutoGameMode']);
  assert.equal(calls[1].op, 'registry.apply');
  assert.equal(calls[1].args.operations.length, 2);
  assert.equal(calls[1].args.operations[0].value, 1);
});

test('registry revert restores existing values and deletes values that did not exist', async () => {
  const action = getAction('game-mode');
  let operations = null;
  const { ps } = fakePs((op, args) => {
    if (op !== 'registry.apply') throw new Error(`unexpected op ${op}`);
    operations = args.operations;
    return args.operations.map(() => ({ ok: true }));
  });

  await action.revert(
    { ps, snapshot: makeSnapshot() },
    {
      kind: 'registry',
      entries: [
        { hive: 'HKCU', path: 'Software\\Test', name: 'Existing', exists: true, kind: 'DWord', value: 0 },
        { hive: 'HKCU', path: 'Software\\Test', name: 'Missing', exists: false },
      ],
    },
  );

  assert.equal(operations.length, 2);
  assert.equal(operations[0].op, 'set');
  assert.equal(operations[0].value, 0);
  assert.equal(operations[0].kind, 'DWord');
  assert.equal(operations[1].op, 'delete');
  assert.equal(operations[1].name, 'Missing');
});

test('registry apply surfaces bridge failures', async () => {
  const action = getAction('game-mode');
  const { ps } = fakePs((op, args) => {
    if (op === 'registry.read') return args.entries.map((entry) => ({ ...entry, exists: false }));
    if (op === 'registry.apply') return [{ ok: false, name: 'AutoGameModeEnabled', error: 'Access denied' }];
    throw new Error(`unexpected op ${op}`);
  });
  await assert.rejects(
    action.apply({ ps, snapshot: makeSnapshot(), admin: false }),
    /AutoGameModeEnabled: Access denied/,
  );
});

test('the Nagle action writes both TCP values for every adapter', async () => {
  const action = getAction('nagle');
  const snapshot = makeSnapshot({
    nagle: [
      { guid: 'aaaaaaaa-1111-2222-3333-444444444444', name: 'Ethernet' },
      { guid: 'bbbbbbbb-1111-2222-3333-444444444444', name: 'Wi-Fi' },
    ],
  });
  let operations = null;
  const { ps } = fakePs((op, args) => {
    if (op === 'registry.read') return args.entries.map((entry) => ({ ...entry, exists: false }));
    if (op === 'registry.apply') {
      operations = args.operations;
      return args.operations.map(() => ({ ok: true }));
    }
    throw new Error(`unexpected op ${op}`);
  });

  const backup = await action.apply({ ps, snapshot, admin: true });
  assert.equal(backup.entries.length, 4);
  assert.equal(operations.length, 4);
  assert.ok(operations[0].path.includes('aaaaaaaa-1111-2222-3333-444444444444'));
  assert.deepEqual(operations.map((operation) => operation.name), [
    'TcpAckFrequency',
    'TCPNoDelay',
    'TcpAckFrequency',
    'TCPNoDelay',
  ]);
});

test('power plan apply remembers the original plan and revert restores it', async () => {
  const action = getAction('power-plan');
  const { ps, calls } = fakePs((op) => {
    if (op === 'power.activateNova') {
      return {
        original: { guid: '381b4222-f694-41f0-9685-ff5bb260df2e', name: 'Balanced' },
        novaGuid: '99999999-9999-9999-9999-999999999999',
        created: true,
      };
    }
    if (op === 'power.setActive') return { guid: '381b4222-f694-41f0-9685-ff5bb260df2e', name: 'Balanced' };
    throw new Error(`unexpected op ${op}`);
  });

  const backup = await action.apply({ ps, snapshot: makeSnapshot(), admin: true });
  assert.equal(backup.kind, 'power');
  assert.equal(backup.originalGuid, '381b4222-f694-41f0-9685-ff5bb260df2e');
  assert.equal(backup.novaGuid, '99999999-9999-9999-9999-999999999999');

  await action.revert({ ps, snapshot: makeSnapshot() }, backup);
  const last = calls[calls.length - 1];
  assert.equal(last.op, 'power.setActive');
  assert.equal(last.args.guid, backup.originalGuid);
  assert.equal(last.args.deleteGuid, backup.novaGuid);
});

test('adapter power revert surfaces failure when no adapter could be restored', async () => {
  const action = getAction('adapter-power');
  const { ps } = fakePs((op) => {
    if (op === 'net.adapterPowerRestore') {
      return [{ name: 'Ethernet', ok: false, error: 'Driver denied request' }];
    }
    throw new Error(`unexpected op ${op}`);
  });
  await assert.rejects(
    action.revert({ ps, snapshot: makeSnapshot() }, { adapters: [{ name: 'Ethernet' }] }),
    /Ethernet: Driver denied request/,
  );
});

test('adapter power actions only target adapters that are up', async () => {
  const action = getAction('adapter-power');
  const snapshot = makeSnapshot({
    adapters: [
      { name: 'Ethernet', status: 'Up', linkSpeed: '1 Gbps' },
      { name: 'Wi-Fi', status: 'Up', linkSpeed: '300 Mbps' },
      { name: 'Bluetooth', status: 'Disconnected' },
    ],
  });
  const { ps, calls } = fakePs((op) => {
    if (op === 'net.adapterPowerDisable') {
      return { adapters: [{ name: 'Ethernet', changed: true }, { name: 'Wi-Fi', changed: true }] };
    }
    if (op === 'net.adapterPowerRestore') return [{ name: 'Ethernet', ok: true }];
    throw new Error(`unexpected op ${op}`);
  });

  const backup = await action.apply({ ps, snapshot, admin: true });
  assert.deepEqual(calls[0].args.names, ['Ethernet', 'Wi-Fi']);
  assert.equal(backup.adapters.length, 2);

  await action.revert({ ps, snapshot }, backup);
  assert.deepEqual(calls[calls.length - 1].args.names, ['Ethernet', 'Wi-Fi']);
});
