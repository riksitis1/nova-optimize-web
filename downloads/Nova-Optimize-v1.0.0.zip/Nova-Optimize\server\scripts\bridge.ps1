param(
  [Parameter(Mandatory = $true)]
  [string]$Payload
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$WarningPreference = 'SilentlyContinue'
$VerbosePreference = 'SilentlyContinue'

try {
  $requestJson = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Payload))
  $request = $requestJson | ConvertFrom-Json
  $op = [string]$request.op
  $p = $request.args
} catch {
  [Console]::Out.WriteLine('NOVA_JSON:{"ok":false,"error":"Invalid bridge payload"}')
  exit 0
}

function Send-Result {
  param($Data, [bool]$Ok = $true)
  if ($Ok) {
    $payload = [ordered]@{ ok = $true; data = $Data }
  } else {
    $payload = [ordered]@{ ok = $false; error = [string]$Data }
  }
  $json = $payload | ConvertTo-Json -Depth 14 -Compress
  [Console]::Out.WriteLine('NOVA_JSON:' + $json)
}

function Get-HiveRoot {
  param([string]$Hive)
  switch ($Hive.ToUpperInvariant()) {
    'HKCU' { return [Microsoft.Win32.Registry]::CurrentUser }
    'HKLM' { return [Microsoft.Win32.Registry]::LocalMachine }
    default { throw "Unsupported registry hive." }
  }
}

function Read-RegValue {
  param($Spec)
  $root = Get-HiveRoot $Spec.hive
  $key = $root.OpenSubKey([string]$Spec.path, $false)
  if ($null -eq $key) {
    return [ordered]@{ exists = $false; hive = $Spec.hive; path = $Spec.path; name = $Spec.name }
  }
  try {
    $name = [string]$Spec.name
    $names = @($key.GetValueNames())
    if ($names -notcontains $name) {
      return [ordered]@{ exists = $false; hive = $Spec.hive; path = $Spec.path; name = $name }
    }
    $kind = $key.GetValueKind($name).ToString()
    $value = $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    if ($kind -eq 'Binary') {
      $value = @($value | ForEach-Object { [int]$_ })
    } elseif ($kind -eq 'MultiString') {
      $value = @($value)
    }
    return [ordered]@{
      exists = $true
      hive = [string]$Spec.hive
      path = [string]$Spec.path
      name = $name
      value = $value
      kind = $kind
    }
  } finally {
    $key.Close()
  }
}

function Set-RegValue {
  param($Spec)
  $root = Get-HiveRoot $Spec.hive
  $key = $root.CreateSubKey([string]$Spec.path)
  if ($null -eq $key) { throw "Could not open registry key." }
  try {
    $name = [string]$Spec.name
    $kind = [string]$Spec.kind
    switch ($kind) {
      'DWord' { $key.SetValue($name, [int32]$Spec.value, [Microsoft.Win32.RegistryValueKind]::DWord) }
      'QWord' { $key.SetValue($name, [int64]$Spec.value, [Microsoft.Win32.RegistryValueKind]::QWord) }
      'Binary' {
        $bytes = [byte[]]@($Spec.value | ForEach-Object { [byte]$_ })
        $key.SetValue($name, $bytes, [Microsoft.Win32.RegistryValueKind]::Binary)
      }
      'MultiString' {
        $strings = [string[]]@($Spec.value)
        $key.SetValue($name, $strings, [Microsoft.Win32.RegistryValueKind]::MultiString)
      }
      'ExpandString' { $key.SetValue($name, [string]$Spec.value, [Microsoft.Win32.RegistryValueKind]::ExpandString) }
      default { $key.SetValue($name, [string]$Spec.value, [Microsoft.Win32.RegistryValueKind]::String) }
    }
  } finally {
    $key.Close()
  }
}

function Delete-RegValue {
  param($Spec)
  $root = Get-HiveRoot $Spec.hive
  $key = $root.OpenSubKey([string]$Spec.path, $true)
  if ($null -eq $key) { return $false }
  try {
    $name = [string]$Spec.name
    if (@($key.GetValueNames()) -contains $name) {
      $key.DeleteValue($name, $false)
      return $true
    }
    return $false
  } finally {
    $key.Close()
  }
}

function Get-PowerPlan {
  $raw = (& powercfg /getactivescheme 2>$null | Out-String).Trim()
  $guid = $null
  $name = 'Unknown'
  if ($raw -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') {
    $guid = $Matches[1].ToLowerInvariant()
  }
  if ($raw -match '\(([^)]+)\)') {
    $name = $Matches[1].Trim()
  }
  return [ordered]@{ guid = $guid; name = $name; raw = $raw }
}

function Test-PendingReboot {
  $checks = @(
    'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
    'SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
  )
  foreach ($path in $checks) {
    $key = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey($path, $false)
    if ($null -ne $key) { $key.Close(); return $true }
  }
  $session = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('SYSTEM\CurrentControlSet\Control\Session Manager', $false)
  if ($null -ne $session) {
    try {
      $pending = $session.GetValue('PendingFileRenameOperations', $null)
      if ($null -ne $pending -and @($pending).Count -gt 0) { return $true }
    } finally {
      $session.Close()
    }
  }
  return $false
}

function Get-StartupEntries {
  $entries = New-Object System.Collections.Generic.List[object]
  $runKeys = @(
    @{ hive = 'HKCU'; path = 'Software\Microsoft\Windows\CurrentVersion\Run'; source = 'User logon'; requiresAdmin = $false },
    @{ hive = 'HKLM'; path = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Run'; source = 'System logon'; requiresAdmin = $true },
    @{ hive = 'HKLM'; path = 'SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run'; source = 'System logon (32-bit)'; requiresAdmin = $true }
  )
  foreach ($item in $runKeys) {
    try {
      $root = Get-HiveRoot $item.hive
      $key = $root.OpenSubKey($item.path, $false)
      if ($null -eq $key) { continue }
      try {
        foreach ($name in @($key.GetValueNames())) {
          if ([string]::IsNullOrWhiteSpace($name)) { continue }
          $value = $key.GetValue($name, $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
          $kind = $key.GetValueKind($name).ToString()
          $entries.Add([ordered]@{
            type = 'registry'
            hive = $item.hive
            path = $item.path
            name = $name
            value = [string]$value
            kind = $kind
            source = $item.source
            command = [string]$value
            requiresAdmin = [bool]$item.requiresAdmin
          })
        }
      } finally {
        $key.Close()
      }
    } catch { }
  }

  $startupFolders = @(
    @{ path = [Environment]::GetFolderPath('Startup'); source = 'User startup folder'; requiresAdmin = $false },
    @{ path = [Environment]::GetFolderPath('CommonStartup'); source = 'All users startup folder'; requiresAdmin = $true }
  )
  foreach ($folder in $startupFolders) {
    try {
      if ([string]::IsNullOrWhiteSpace($folder.path) -or -not (Test-Path -LiteralPath $folder.path)) { continue }
      foreach ($file in @(Get-ChildItem -LiteralPath $folder.path -Force -File -ErrorAction SilentlyContinue)) {
        if ($file.Name -ieq 'desktop.ini') { continue }
        $entries.Add([ordered]@{
          type = 'file'
          filePath = $file.FullName
          name = $file.Name
          source = $folder.source
          command = $file.FullName
          kind = 'File'
          requiresAdmin = [bool]$folder.requiresAdmin
        })
      }
    } catch { }
  }
  return $entries.ToArray()
}

function Get-FolderInfo {
  param([string[]]$Paths, [int]$MinAgeHours = 0)
  $bytes = [int64]0
  $files = 0
  $cutoff = (Get-Date).AddHours(-1 * $MinAgeHours)
  foreach ($path in $Paths) {
    try {
      if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path)) { continue }
      $children = @(Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue)
      foreach ($child in $children) {
        try {
          if ($child.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
          if ($child.PSIsContainer) {
            $items = @(Get-ChildItem -LiteralPath $child.FullName -Recurse -Force -File -ErrorAction SilentlyContinue)
          } else {
            $items = @($child)
          }
          foreach ($file in $items) {
            if ($file.LastWriteTime -ge $cutoff) { continue }
            $bytes += [int64]$file.Length
            $files++
          }
        } catch { }
      }
    } catch { }
  }
  return [ordered]@{ bytes = $bytes; files = $files }
}

function Get-CleanupDefinitions {
  $local = $env:LOCALAPPDATA
  $roaming = $env:APPDATA
  $windir = $env:WINDIR
  $programData = $env:ProgramData
  $browserPaths = New-Object System.Collections.Generic.List[string]
  $browserRoots = @(
    (Join-Path $local 'Google\Chrome\User Data'),
    (Join-Path $local 'Microsoft\Edge\User Data'),
    (Join-Path $local 'BraveSoftware\Brave-Browser\User Data'),
    (Join-Path $local 'Vivaldi\User Data')
  )
  foreach ($root in $browserRoots) {
    try {
      if (-not (Test-Path -LiteralPath $root)) { continue }
      foreach ($profile in @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue)) {
        if ($profile.Name -notmatch '^(Default|Profile \d+|Guest Profile)$') { continue }
        foreach ($cacheName in @('Cache', 'Code Cache', 'GPUCache')) {
          $candidate = Join-Path $profile.FullName $cacheName
          if (Test-Path -LiteralPath $candidate) { $browserPaths.Add($candidate) }
        }
      }
    } catch { }
  }
  $firefoxRoot = Join-Path $local 'Mozilla\Firefox\Profiles'
  try {
    if (Test-Path -LiteralPath $firefoxRoot) {
      foreach ($profile in @(Get-ChildItem -LiteralPath $firefoxRoot -Directory -ErrorAction SilentlyContinue)) {
        foreach ($cacheName in @('cache2', 'startupCache', 'jumpListCache')) {
          $candidate = Join-Path $profile.FullName $cacheName
          if (Test-Path -LiteralPath $candidate) { $browserPaths.Add($candidate) }
        }
      }
    }
  } catch { }

  return [ordered]@{
    'user-temp' = [ordered]@{
      label = 'User temp files'; description = 'Temporary files left by apps and installers.'; risk = 'safe'
      paths = @($env:TEMP); minAgeHours = 1; requiresAdmin = $false
    }
    'windows-temp' = [ordered]@{
      label = 'Windows temp files'; description = 'System-level temporary files. Open files are skipped.'; risk = 'safe'
      paths = @((Join-Path $windir 'Temp')); minAgeHours = 1; requiresAdmin = $true
    }
    'crash-dumps' = [ordered]@{
      label = 'Crash dumps'; description = 'Memory dumps from apps that crashed.'; risk = 'safe'
      paths = @((Join-Path $local 'CrashDumps')); minAgeHours = 1; requiresAdmin = $false
    }
    'error-reports' = [ordered]@{
      label = 'Windows error reports'; description = 'Queued and archived Windows Error Reporting data.'; risk = 'safe'
      paths = @(
        (Join-Path $programData 'Microsoft\Windows\WER\ReportQueue'),
        (Join-Path $programData 'Microsoft\Windows\WER\ReportArchive')
      ); minAgeHours = 24; requiresAdmin = $true
    }
    'shader-cache' = [ordered]@{
      label = 'GPU shader caches'; description = 'DirectX and driver shader caches. They rebuild automatically.'; risk = 'safe'
      paths = @(
        (Join-Path $local 'D3DSCache'),
        (Join-Path $local 'NVIDIA\DXCache'),
        (Join-Path $local 'NVIDIA\GLCache'),
        (Join-Path $local 'AMD\DxCache'),
        (Join-Path $local 'AMD\GLCache')
      ); minAgeHours = 0; requiresAdmin = $false
    }
    'browser-cache' = [ordered]@{
      label = 'Browser caches'; description = 'Chrome, Edge, Brave, Vivaldi and Firefox cache data. Close browsers first.'; risk = 'caution'
      paths = @($browserPaths); minAgeHours = 1; requiresAdmin = $false; needsBrowserClosed = $true
    }
    'recycle-bin' = [ordered]@{
      label = 'Recycle Bin'; description = 'Files you have already deleted. Emptying is permanent and cannot be undone.'; risk = 'caution'
      paths = @(); minAgeHours = 0; requiresAdmin = $false; recycleBin = $true
    }
  }
}

function Get-RecycleBinInfo {
  try {
    $shell = New-Object -ComObject Shell.Application
    $namespace = $shell.Namespace(10)
    if ($null -eq $namespace) { return [ordered]@{ bytes = 0; files = 0 } }
    $bytes = [int64]0
    $files = 0
    foreach ($item in @($namespace.Items())) {
      try { $bytes += [int64]$item.Size; $files++ } catch { }
    }
    return [ordered]@{ bytes = $bytes; files = $files }
  } catch {
    return [ordered]@{ bytes = 0; files = 0 }
  }
}

function Get-CleanupScan {
  $definitions = Get-CleanupDefinitions
  $result = New-Object System.Collections.Generic.List[object]
  foreach ($id in $definitions.Keys) {
    $definition = $definitions[$id]
    if ($definition.recycleBin) {
      $info = Get-RecycleBinInfo
    } else {
      $info = Get-FolderInfo -Paths @($definition.paths) -MinAgeHours ([int]$definition.minAgeHours)
    }
    $result.Add([ordered]@{
      id = $id
      label = $definition.label
      description = $definition.description
      risk = $definition.risk
      bytes = $info.bytes
      files = $info.files
      requiresAdmin = [bool]$definition.requiresAdmin
      needsBrowserClosed = [bool]($definition.needsBrowserClosed -eq $true)
      recycleBin = [bool]($definition.recycleBin -eq $true)
    })
  }
  return @($result | Sort-Object -Property @{ Expression = { $_.bytes }; Descending = $true })
}

function Remove-CleanupCategory {
  param([string]$Id)
  $definitions = Get-CleanupDefinitions
  if (-not $definitions.Contains($Id)) { throw "Unknown cleanup category." }
  $definition = $definitions[$Id]
  if ($definition.needsBrowserClosed) {
    $running = @(Get-Process -Name chrome, msedge, brave, vivaldi, firefox -ErrorAction SilentlyContinue)
    if ($running.Count -gt 0) {
      return [ordered]@{ id = $Id; skipped = $true; reason = 'Close your browser before cleaning its cache.'; bytes = 0; files = 0; errors = @() }
    }
  }
  if ($definition.recycleBin) {
    $before = Get-RecycleBinInfo
    try { Clear-RecycleBin -Force -ErrorAction Stop } catch { }
    $after = Get-RecycleBinInfo
    return [ordered]@{
      id = $Id; skipped = $false; bytes = [Math]::Max(0, $before.bytes - $after.bytes)
      files = [Math]::Max(0, $before.files - $after.files); errors = @()
    }
  }

  $before = Get-FolderInfo -Paths @($definition.paths) -MinAgeHours ([int]$definition.minAgeHours)
  $errors = New-Object System.Collections.Generic.List[string]
  $cutoff = (Get-Date).AddHours(-1 * [int]$definition.minAgeHours)
  foreach ($path in @($definition.paths)) {
    try {
      if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path)) { continue }
      foreach ($child in @(Get-ChildItem -LiteralPath $path -Force -ErrorAction SilentlyContinue)) {
        try {
          if ($child.Attributes -band [IO.FileAttributes]::ReparsePoint) { continue }
          if ($child.PSIsContainer) {
            Remove-Item -LiteralPath $child.FullName -Recurse -Force -ErrorAction Stop
          } elseif ($child.LastWriteTime -lt $cutoff) {
            Remove-Item -LiteralPath $child.FullName -Force -ErrorAction Stop
          }
        } catch {
          if ($errors.Count -lt 12) { $errors.Add($_.Exception.Message) }
        }
      }
    } catch {
      if ($errors.Count -lt 12) { $errors.Add($_.Exception.Message) }
    }
  }
  $after = Get-FolderInfo -Paths @($definition.paths) -MinAgeHours ([int]$definition.minAgeHours)
  return [ordered]@{
    id = $Id
    skipped = $false
    bytes = [Math]::Max(0, $before.bytes - $after.bytes)
    files = [Math]::Max(0, $before.files - $after.files)
    errors = $errors.ToArray()
  }
}

function Get-DnsInfo {
  $adapters = New-Object System.Collections.Generic.List[object]
  $items = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' })
  foreach ($adapter in $items) {
    try {
      $dns4 = @(Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object { $_.ServerAddresses })
      $dns6 = @(Get-DnsClientServerAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv6 -ErrorAction SilentlyContinue | ForEach-Object { $_.ServerAddresses })
      $ip4 = @(Get-NetIPAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '169.254.*' } | ForEach-Object { $_.IPAddress })
      $ip6 = @(Get-NetIPAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv6 -ErrorAction SilentlyContinue | ForEach-Object { $_.IPAddress })
      $mode = 'dhcp'
      try {
        $spec = @{ hive = 'HKLM'; path = "SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($adapter.InterfaceGuid)"; name = 'NameServer' }
        $static = Read-RegValue $spec
        if ($static.exists -and -not [string]::IsNullOrWhiteSpace([string]$static.value)) { $mode = 'static' }
      } catch { }
      $adapters.Add([ordered]@{
        ifIndex = $adapter.ifIndex
        name = $adapter.Name
        description = $adapter.InterfaceDescription
        mediaType = [string]$adapter.MediaType
        linkSpeed = [string]$adapter.LinkSpeed
        macAddress = [string]$adapter.MacAddress
        guid = [string]$adapter.InterfaceGuid
        dns4 = @($dns4 | Where-Object { $_ })
        dns6 = @($dns6 | Where-Object { $_ })
        ipv4 = @($ip4)
        ipv6 = @($ip6)
        mode = $mode
      })
    } catch { }
  }
  return $adapters.ToArray()
}

function Set-DnsServers {
  param([int[]]$IfIndexes, [string[]]$Servers)
  $results = New-Object System.Collections.Generic.List[object]
  foreach ($index in $IfIndexes) {
    try {
      Set-DnsClientServerAddress -InterfaceIndex $index -ServerAddresses $Servers -ErrorAction Stop
      $results.Add([ordered]@{ ifIndex = $index; ok = $true })
    } catch {
      $results.Add([ordered]@{ ifIndex = $index; ok = $false; error = $_.Exception.Message })
    }
  }
  return $results.ToArray()
}

function Reset-DnsServers {
  param($Backups)
  $results = New-Object System.Collections.Generic.List[object]
  foreach ($backup in @($Backups)) {
    try {
      if ([string]$backup.mode -eq 'static' -and @($backup.servers).Count -gt 0) {
        Set-DnsClientServerAddress -InterfaceIndex ([int]$backup.ifIndex) -ServerAddresses ([string[]]$backup.servers) -ErrorAction Stop
      } else {
        Set-DnsClientServerAddress -InterfaceIndex ([int]$backup.ifIndex) -ResetServerAddresses -ErrorAction Stop
      }
      $results.Add([ordered]@{ ifIndex = [int]$backup.ifIndex; ok = $true })
    } catch {
      $results.Add([ordered]@{ ifIndex = [int]$backup.ifIndex; ok = $false; error = $_.Exception.Message })
    }
  }
  return $results.ToArray()
}

function Invoke-Ping {
  param([string]$HostName, [int]$Count)
  $count = [Math]::Min(20, [Math]::Max(1, $Count))
  $ping = New-Object System.Net.NetworkInformation.Ping
  $times = New-Object System.Collections.Generic.List[object]
  $address = $null
  try {
    $addresses = [System.Net.Dns]::GetHostAddresses($HostName)
    $first = @($addresses | Where-Object { $_.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetwork } | Select-Object -First 1)
    if ($first.Count -gt 0) { $address = $first[0].ToString() } elseif ($addresses.Count -gt 0) { $address = $addresses[0].ToString() }
  } catch { }
  for ($i = 0; $i -lt $count; $i++) {
    try {
      $reply = $ping.Send($HostName, 1200)
      if ($reply.Status -eq [System.Net.NetworkInformation.IPStatus]::Success) {
        $times.Add([int]$reply.RoundtripTime)
      } else {
        $times.Add($null)
      }
    } catch {
      $times.Add($null)
    }
    if ($i -lt ($count - 1)) { Start-Sleep -Milliseconds 120 }
  }
  $okTimes = @($times | Where-Object { $null -ne $_ })
  $received = $okTimes.Count
  $sent = $count
  $loss = if ($sent -gt 0) { [Math]::Round((($sent - $received) / $sent) * 100, 1) } else { 100 }
  if ($received -eq 0) {
    return [ordered]@{ host = $HostName; address = $address; count = $sent; received = 0; loss = 100; min = $null; avg = $null; max = $null; jitter = $null; times = $times.ToArray() }
  }
  $min = ($okTimes | Measure-Object -Minimum).Minimum
  $max = ($okTimes | Measure-Object -Maximum).Maximum
  $avg = [Math]::Round(($okTimes | Measure-Object -Average).Average, 1)
  $diffs = @()
  for ($i = 1; $i -lt $okTimes.Count; $i++) { $diffs += [Math]::Abs([double]$okTimes[$i] - [double]$okTimes[$i - 1]) }
  $jitter = if ($diffs.Count -gt 0) { [Math]::Round(($diffs | Measure-Object -Average).Average, 1) } else { 0 }
  return [ordered]@{
    host = $HostName; address = $address; count = $sent; received = $received; loss = $loss
    min = $min; avg = $avg; max = $max; jitter = $jitter; times = $times.ToArray()
  }
}

function Get-ProcessSnapshot {
  $first = @{}
  foreach ($process in @(Get-Process -ErrorAction SilentlyContinue)) {
    try { $first[[int]$process.Id] = [double]$process.CPU } catch { }
  }
  Start-Sleep -Milliseconds 650
  $cores = [Math]::Max(1, [Environment]::ProcessorCount)
  $rows = New-Object System.Collections.Generic.List[object]
  foreach ($process in @(Get-Process -ErrorAction SilentlyContinue)) {
    try {
      $id = [int]$process.Id
      $cpu = [double]$process.CPU
      $delta = if ($first.ContainsKey($id)) { [Math]::Max(0, $cpu - $first[$id]) } else { 0 }
      $rows.Add([ordered]@{
        pid = $id
        name = $process.ProcessName
        cpu = [Math]::Round(($delta / 0.65 / $cores) * 100, 1)
        memory = [int64]$process.WorkingSet64
        path = try { [string]$process.Path } catch { '' }
      })
    } catch { }
  }
  $byCpu = @($rows | Sort-Object -Property cpu -Descending | Select-Object -First 12)
  $byMemory = @($rows | Sort-Object -Property memory -Descending | Select-Object -First 12)
  return [ordered]@{ byCpu = $byCpu; byMemory = $byMemory; processCount = $rows.Count }
}

function Get-Snapshot {
  $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
  $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction Stop
  $cpu = @(Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1)
  $gpus = @(Get-CimInstance Win32_VideoController -ErrorAction SilentlyContinue)
  $memoryModules = @(Get-CimInstance Win32_PhysicalMemory -ErrorAction SilentlyContinue)
  $logicalDisks = @(Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" -ErrorAction SilentlyContinue)
  $physicalDisks = @()
  try { $physicalDisks = @(Get-PhysicalDisk -ErrorAction SilentlyContinue | Select-Object FriendlyName, MediaType, Size, HealthStatus, BusType) } catch { }
  $battery = @(Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)
  $adapters = @()
  try {
    $adapters = @(Get-NetAdapter -Physical -ErrorAction SilentlyContinue | ForEach-Object {
      $adapter = $_
      $ipv4 = @()
      try { $ipv4 = @(Get-NetIPAddress -InterfaceIndex $adapter.ifIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '169.254.*' } | ForEach-Object { $_.IPAddress }) } catch { }
      $allowPowerOff = $null
      try {
        $pm = Get-NetAdapterPowerManagement -Name $adapter.Name -ErrorAction Stop
        if ($null -ne $pm) { $allowPowerOff = [bool]$pm.AllowComputerToTurnOffDevice }
      } catch { }
      [ordered]@{
        name = $adapter.Name
        description = $adapter.InterfaceDescription
        status = [string]$adapter.Status
        mediaType = [string]$adapter.MediaType
        linkSpeed = [string]$adapter.LinkSpeed
        macAddress = [string]$adapter.MacAddress
        ifIndex = $adapter.ifIndex
        guid = [string]$adapter.InterfaceGuid
        ipv4 = @($ipv4)
        allowComputerToTurnOffDevice = $allowPowerOff
      }
    })
  } catch { }

  $nagle = @()
  foreach ($adapter in @($adapters | Where-Object { $_.status -eq 'Up' -and @($_.ipv4).Count -gt 0 })) {
    try {
      $base = "SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces\$($adapter.guid)"
      $ack = Read-RegValue @{ hive = 'HKLM'; path = $base; name = 'TcpAckFrequency' }
      $delay = Read-RegValue @{ hive = 'HKLM'; path = $base; name = 'TCPNoDelay' }
      $nagle += [ordered]@{
        name = $adapter.name; ifIndex = $adapter.ifIndex; guid = $adapter.guid
        tcpAckFrequency = if ($ack.exists) { $ack.value } else { $null }
        tcpNoDelay = if ($delay.exists) { $delay.value } else { $null }
      }
    } catch { }
  }

  $security = [ordered]@{
    secureBoot = $null
    tpm = $null
    defender = $null
    firewall = @()
  }
  try { $security.secureBoot = [bool](Confirm-SecureBootUEFI -ErrorAction Stop) } catch { }
  try {
    $tpm = Get-CimInstance -Namespace 'root\CIMV2\Security\MicrosoftTpm' -ClassName Win32_Tpm -ErrorAction Stop
    $security.tpm = if ($null -ne $tpm) { [bool]$tpm.IsEnabled_InitialValue } else { $null }
  } catch { }
  try {
    $defender = Get-MpComputerStatus -ErrorAction Stop
    $security.defender = [ordered]@{
      antivirusEnabled = [bool]$defender.AntivirusEnabled
      realTimeProtectionEnabled = [bool]$defender.RealTimeProtectionEnabled
      antispywareEnabled = [bool]$defender.AntispywareEnabled
      amServiceEnabled = [bool]$defender.AMServiceEnabled
      signatureVersion = [string]$defender.AntivirusSignatureVersion
    }
  } catch { }
  try {
    $security.firewall = @(Get-NetFirewallProfile -ErrorAction SilentlyContinue | ForEach-Object {
      [ordered]@{ name = [string]$_.Name; enabled = [bool]$_.Enabled }
    })
  } catch { }

  $power = Get-PowerPlan
  $state = [ordered]@{
    gameMode = [ordered]@{
      autoGameMode = Read-RegValue @{ hive = 'HKCU'; path = 'Software\Microsoft\GameBar'; name = 'AutoGameModeEnabled' }
      allowAutoGameMode = Read-RegValue @{ hive = 'HKCU'; path = 'Software\Microsoft\GameBar'; name = 'AllowAutoGameMode' }
    }
    gameDvr = [ordered]@{
      gameDvrEnabled = Read-RegValue @{ hive = 'HKCU'; path = 'System\GameConfigStore'; name = 'GameDVR_Enabled' }
      appCaptureEnabled = Read-RegValue @{ hive = 'HKCU'; path = 'Software\Microsoft\Windows\CurrentVersion\GameDVR'; name = 'AppCaptureEnabled' }
    }
    hags = Read-RegValue @{ hive = 'HKLM'; path = 'SYSTEM\CurrentControlSet\Control\GraphicsDrivers'; name = 'HwSchMode' }
    windowed = Read-RegValue @{ hive = 'HKCU'; path = 'Software\Microsoft\DirectX\GraphicsSettings'; name = 'SwapEffectUpgradeEnable' }
    transparency = Read-RegValue @{ hive = 'HKCU'; path = 'Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'; name = 'EnableTransparency' }
    backgroundApps = Read-RegValue @{ hive = 'HKCU'; path = 'Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications'; name = 'GlobalUserDisabled' }
    networkThrottling = Read-RegValue @{ hive = 'HKLM'; path = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'; name = 'NetworkThrottlingIndex' }
    systemResponsiveness = Read-RegValue @{ hive = 'HKLM'; path = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'; name = 'SystemResponsiveness' }
    gamesTask = [ordered]@{
      gpuPriority = Read-RegValue @{ hive = 'HKLM'; path = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; name = 'GPU Priority' }
      priority = Read-RegValue @{ hive = 'HKLM'; path = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; name = 'Priority' }
      schedulingCategory = Read-RegValue @{ hive = 'HKLM'; path = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; name = 'Scheduling Category' }
      sfioPriority = Read-RegValue @{ hive = 'HKLM'; path = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; name = 'SFIO Priority' }
    }
    mouse = [ordered]@{
      mouseSpeed = Read-RegValue @{ hive = 'HKCU'; path = 'Control Panel\Mouse'; name = 'MouseSpeed' }
      threshold1 = Read-RegValue @{ hive = 'HKCU'; path = 'Control Panel\Mouse'; name = 'MouseThreshold1' }
      threshold2 = Read-RegValue @{ hive = 'HKCU'; path = 'Control Panel\Mouse'; name = 'MouseThreshold2' }
    }
    deliveryOptimization = Read-RegValue @{ hive = 'HKCU'; path = 'Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config'; name = 'DODownloadMode' }
    win32PrioritySeparation = Read-RegValue @{ hive = 'HKLM'; path = 'SYSTEM\CurrentControlSet\Control\PriorityControl'; name = 'Win32PrioritySeparation' }
    powerThrottlingOff = Read-RegValue @{ hive = 'HKLM'; path = 'SYSTEM\CurrentControlSet\Control\Power\PowerThrottling'; name = 'PowerThrottlingOff' }
    tcpAutotuning = Get-TcpGlobalState
  }

  $startup = @(Get-StartupEntries)
  $admin = $false
  try {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    $admin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
  } catch { }

  $uptime = 0
  try { $uptime = [int64]((Get-Date) - $os.LastBootUpTime).TotalSeconds } catch { }
  $totalRam = [int64]$cs.TotalPhysicalMemory
  $freeRam = [int64]$os.FreePhysicalMemory * 1024
  $bootDisk = $null
  try { $bootDisk = @($logicalDisks | Where-Object { $_.DeviceID -eq $env:SystemDrive } | Select-Object -First 1)[0] } catch { }

  return [ordered]@{
    generatedAt = (Get-Date).ToUniversalTime().ToString('o')
    admin = $admin
    hostname = $env:COMPUTERNAME
    username = $env:USERNAME
    os = [ordered]@{
      caption = [string]$os.Caption
      version = [string]$os.Version
      build = [int]$os.BuildNumber
      architecture = [string]$os.OSArchitecture
      installDate = if ($os.InstallDate) { $os.InstallDate.ToString('yyyy-MM-dd') } else { $null }
      lastBoot = if ($os.LastBootUpTime) { $os.LastBootUpTime.ToString('o') } else { $null }
      uptimeSeconds = $uptime
    }
    computer = [ordered]@{
      manufacturer = [string]$cs.Manufacturer
      model = [string]$cs.Model
      isLaptop = ($battery.Count -gt 0)
      totalRam = $totalRam
      freeRam = $freeRam
      memoryUsagePercent = if ($totalRam -gt 0) { [Math]::Round((($totalRam - $freeRam) / $totalRam) * 100, 1) } else { 0 }
    }
    cpu = if ($cpu.Count -gt 0) { [ordered]@{
      name = [string]$cpu[0].Name
      manufacturer = [string]$cpu[0].Manufacturer
      cores = [int]$cpu[0].NumberOfCores
      threads = [int]$cpu[0].NumberOfLogicalProcessors
      maxClockMhz = [int]$cpu[0].MaxClockSpeed
    } } else { $null }
    gpus = @($gpus | ForEach-Object {
      [ordered]@{
        name = [string]$_.Name
        vram = if ($_.AdapterRAM) { [int64]$_.AdapterRAM } else { 0 }
        driverVersion = [string]$_.DriverVersion
        driverDate = if ($_.DriverDate) { $_.DriverDate.ToString('yyyy-MM-dd') } else { $null }
        processor = [string]$_.VideoProcessor
        refreshRate = if ($_.CurrentRefreshRate) { [int]$_.CurrentRefreshRate } else { $null }
        resolution = if ($_.CurrentHorizontalResolution -and $_.CurrentVerticalResolution) { "$($_.CurrentHorizontalResolution)x$($_.CurrentVerticalResolution)" } else { $null }
        status = [string]$_.Status
      }
    })
    memoryModules = @($memoryModules | ForEach-Object {
      [ordered]@{
        capacity = [int64]$_.Capacity
        speed = if ($_.ConfiguredClockSpeed) { [int]$_.ConfiguredClockSpeed } elseif ($_.Speed) { [int]$_.Speed } else { $null }
        manufacturer = [string]$_.Manufacturer
        partNumber = [string]$_.PartNumber
        slot = [string]$_.DeviceLocator
      }
    })
    disks = @($logicalDisks | ForEach-Object {
      [ordered]@{
        id = [string]$_.DeviceID
        label = [string]$_.VolumeName
        size = [int64]$_.Size
        free = [int64]$_.FreeSpace
        fileSystem = [string]$_.FileSystem
        usedPercent = if ($_.Size -gt 0) { [Math]::Round((($_.Size - $_.FreeSpace) / $_.Size) * 100, 1) } else { 0 }
      }
    })
    physicalDisks = @($physicalDisks | ForEach-Object {
      [ordered]@{
        name = [string]$_.FriendlyName
        mediaType = [string]$_.MediaType
        size = [int64]$_.Size
        health = [string]$_.HealthStatus
        busType = [string]$_.BusType
      }
    })
    adapters = @($adapters)
    battery = if ($battery.Count -gt 0) { [ordered]@{ present = $true; status = [string]$battery[0].BatteryStatus; charge = [int]$battery[0].EstimatedChargeRemaining } } else { [ordered]@{ present = $false } }
    power = $power
    security = $security
    pendingReboot = Test-PendingReboot
    state = $state
    nagle = @($nagle)
    startup = @($startup)
    startupCount = @($startup).Count
    bootDisk = if ($bootDisk) { [ordered]@{ id = [string]$bootDisk.DeviceID; size = [int64]$bootDisk.Size; free = [int64]$bootDisk.FreeSpace } } else { $null }
  }
}

function Activate-NovaPowerPlan {
  $original = Get-PowerPlan
  $list = (& powercfg /list 2>$null | Out-String)
  $novaGuid = $null
  $lines = @($list -split "`r?`n")
  foreach ($line in $lines) {
    if ($line -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})\s+\(Nova Gaming\)') {
      $novaGuid = $Matches[1].ToLowerInvariant()
      break
    }
  }
  $created = $false
  if (-not $novaGuid) {
    $highPerformance = '8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c'
    $output = (& powercfg -duplicatescheme $highPerformance 2>$null | Out-String)
    if ($output -match '([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})') {
      $novaGuid = $Matches[1].ToLowerInvariant()
      $created = $true
      & powercfg -changename $novaGuid 'Nova Gaming' 'High performance plan created by Nova Optimize' 2>$null | Out-Null
    }
  }
  if (-not $novaGuid) { throw 'Could not create the Nova Gaming power plan.' }
  & powercfg /setactive $novaGuid 2>$null | Out-Null
  if ($LASTEXITCODE -ne 0) { throw 'Windows refused to activate the Nova Gaming power plan. Run Nova as administrator.' }
  $active = Get-PowerPlan
  return [ordered]@{
    original = $original
    active = $active
    novaGuid = $novaGuid
    created = $created
  }
}

function Get-TcpGlobalState {
  $autoTuning = 'Normal'
  $scalingHeuristics = 'Disabled'
  $rss = 'Enabled'
  try {
    $tcp = Get-NetTCPSetting -SettingName Internet -ErrorAction Stop | Select-Object -First 1
    if ($null -ne $tcp) {
      if ($tcp.AutoTuningLevelLocal) { $autoTuning = [string]$tcp.AutoTuningLevelLocal }
      if ($tcp.ScalingHeuristics) { $scalingHeuristics = [string]$tcp.ScalingHeuristics }
    }
  } catch { }
  try {
    $offload = Get-NetOffloadGlobalSetting -ErrorAction Stop
    if ($null -ne $offload -and $offload.ReceiveSideScaling) {
      $rss = [string]$offload.ReceiveSideScaling
    }
  } catch { }
  return [ordered]@{
    autoTuning = $autoTuning
    scalingHeuristics = $scalingHeuristics
    rss = $rss
  }
}

function Invoke-MemoryTrim {
  $cs = @"
using System;
using System.Runtime.InteropServices;
public static class NovaMem {
  [DllImport("psapi.dll")]
  public static extern bool EmptyWorkingSet(IntPtr hProcess);
}
"@
  try { Add-Type -TypeDefinition $cs -ErrorAction SilentlyContinue } catch { }
  $osBefore = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
  $beforeFree = if ($osBefore) { [int64]$osBefore.FreePhysicalMemory * 1024 } else { 0 }
  $skip = @('Idle','System','Registry','smss','csrss','wininit','services','lsass','svchost','dwm','explorer','Memory Compression','audiodg','MsMpEng','NisSrv','SecurityHealthService','vgc','vgtray')
  $trimmed = 0
  foreach ($proc in @(Get-Process -ErrorAction SilentlyContinue)) {
    try {
      if ($skip -contains $proc.ProcessName) { continue }
      if ($proc.WorkingSet64 -lt 15MB) { continue }
      if ($proc.Handle -and [NovaMem]::EmptyWorkingSet($proc.Handle)) {
        $trimmed++
      }
    } catch { }
  }
  try { [System.GC]::Collect() } catch { }
  Start-Sleep -Milliseconds 180
  $osAfter = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
  $afterFree = if ($osAfter) { [int64]$osAfter.FreePhysicalMemory * 1024 } else { $beforeFree }
  $freed = [Math]::Max([int64]0, $afterFree - $beforeFree)
  return [ordered]@{
    ok = $true
    trimmedProcesses = $trimmed
    beforeFreeBytes = $beforeFree
    afterFreeBytes = $afterFree
    freedBytes = $freed
  }
}

try {
  switch ($op) {
    'snapshot' { Send-Result (Get-Snapshot) }
    'registry.read' {
      $result = New-Object System.Collections.Generic.List[object]
      foreach ($spec in @($p.entries)) { $result.Add((Read-RegValue $spec)) }
      Send-Result $result.ToArray()
    }
    'registry.apply' {
      $result = New-Object System.Collections.Generic.List[object]
      foreach ($item in @($p.operations)) {
        try {
          if ([string]$item.op -eq 'delete') {
            $changed = Delete-RegValue $item
            $result.Add([ordered]@{ ok = $true; op = 'delete'; changed = [bool]$changed; name = $item.name })
          } else {
            Set-RegValue $item
            $result.Add([ordered]@{ ok = $true; op = 'set'; name = $item.name })
          }
        } catch {
          $result.Add([ordered]@{ ok = $false; op = [string]$item.op; name = $item.name; error = $_.Exception.Message })
        }
      }
      Send-Result $result.ToArray()
    }
    'power.get' { Send-Result (Get-PowerPlan) }
    'power.activateNova' { Send-Result (Activate-NovaPowerPlan) }
    'power.setActive' {
      if ([string]$p.guid -notmatch '^[0-9a-fA-F-]{36}$') { throw 'Invalid power plan.' }
      & powercfg /setactive ([string]$p.guid) 2>$null | Out-Null
      if ($LASTEXITCODE -ne 0) { throw 'Could not activate the power plan.' }
      if ($p.deleteGuid -and ([string]$p.deleteGuid -match '^[0-9a-fA-F-]{36}$') -and ([string]$p.deleteGuid -ne [string]$p.guid)) {
        & powercfg /delete ([string]$p.deleteGuid) 2>$null | Out-Null
      }
      Send-Result (Get-PowerPlan)
    }
    'startup.disable' {
      if ([string]$p.entry.type -eq 'file') {
        $source = [string]$p.entry.filePath
        if (-not (Test-Path -LiteralPath $source)) { throw 'Startup file no longer exists.' }
        $backupDir = [string]$p.backupDir
        if ([string]::IsNullOrWhiteSpace($backupDir)) { throw 'Missing backup directory.' }
        New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        $target = Join-Path $backupDir ((Get-Date).ToString('yyyyMMddHHmmss') + '_' + [IO.Path]::GetFileName($source))
        Move-Item -LiteralPath $source -Destination $target -Force -ErrorAction Stop
        Send-Result ([ordered]@{ type = 'file'; originalPath = $source; backupPath = $target })
      } else {
        $spec = @{ hive = [string]$p.entry.hive; path = [string]$p.entry.path; name = [string]$p.entry.name }
        $current = Read-RegValue $spec
        if (-not $current.exists) { throw 'Startup entry no longer exists.' }
        Delete-RegValue $spec | Out-Null
        Send-Result ([ordered]@{ type = 'registry'; entry = $current })
      }
    }
    'startup.enable' {
      $entry = $p.entry
      if ([string]$entry.type -eq 'file') {
        if (-not (Test-Path -LiteralPath ([string]$entry.backupPath))) { throw 'Backup file is missing.' }
        $destination = [string]$entry.originalPath
        $parent = Split-Path -Parent $destination
        if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
        Move-Item -LiteralPath ([string]$entry.backupPath) -Destination $destination -Force -ErrorAction Stop
      } else {
        Set-RegValue @{ hive = $entry.entry.hive; path = $entry.entry.path; name = $entry.entry.name; kind = $entry.entry.kind; value = $entry.entry.value }
      }
      Send-Result ([ordered]@{ ok = $true })
    }
    'cleanup.scan' { Send-Result (Get-CleanupScan) }
    'cleanup.run' {
      $results = New-Object System.Collections.Generic.List[object]
      foreach ($id in @($p.ids)) { $results.Add((Remove-CleanupCategory -Id ([string]$id))) }
      Send-Result $results.ToArray()
    }
    'dns.get' { Send-Result (Get-DnsInfo) }
    'dns.apply' { Send-Result (Set-DnsServers -IfIndexes @($p.ifIndexes) -Servers @($p.servers)) }
    'dns.reset' { Send-Result (Reset-DnsServers -Backups $p.backups) }
    'dns.flush' { Clear-DnsClientCache -ErrorAction SilentlyContinue; Send-Result ([ordered]@{ ok = $true }) }
    'net.adapterPowerDisable' {
      $results = New-Object System.Collections.Generic.List[object]
      foreach ($name in @($p.names)) {
        try {
          $before = $null
          try { $before = Get-NetAdapterPowerManagement -Name ([string]$name) -ErrorAction Stop } catch { }
          Disable-NetAdapterPowerManagement -Name ([string]$name) -ErrorAction Stop
          $results.Add([ordered]@{
            name = [string]$name; changed = $true
            previous = if ($null -ne $before) { $before.AllowComputerToTurnOffDevice } else { $null }
          })
        } catch {
          $results.Add([ordered]@{ name = [string]$name; changed = $false; error = $_.Exception.Message })
        }
      }
      $changed = @($results | Where-Object { $_.changed -eq $true })
      if ($changed.Count -eq 0) {
        $reason = ($results | Select-Object -First 1).error
        throw "Could not change adapter power settings. $reason"
      }
      Send-Result ([ordered]@{ adapters = @($results | Where-Object { $_.changed -eq $true }) })
    }
    'net.adapterPowerRestore' {
      $results = New-Object System.Collections.Generic.List[object]
      foreach ($name in @($p.names)) {
        try {
          Enable-NetAdapterPowerManagement -Name ([string]$name) -ErrorAction Stop
          $results.Add([ordered]@{ name = [string]$name; ok = $true })
        } catch {
          $results.Add([ordered]@{ name = [string]$name; ok = $false; error = $_.Exception.Message })
        }
      }
      Send-Result $results.ToArray()
    }
    'ping' { Send-Result (Invoke-Ping -HostName ([string]$p.host) -Count ([int]$p.count)) }
    'processes' { Send-Result (Get-ProcessSnapshot) }
    'memory.trim' { Send-Result (Invoke-MemoryTrim) }
    'net.tcpAutotune' {
      $before = Get-TcpGlobalState
      $level = if ($p.autoTuning) { [string]$p.autoTuning } else { 'normal' }
      $heuristics = if ($p.scalingHeuristics) { [string]$p.scalingHeuristics } else { 'disabled' }
      $rss = if ($p.rss) { [string]$p.rss } else { 'enabled' }
      & netsh interface tcp set global autotuninglevel=$level 2>$null | Out-Null
      if ($LASTEXITCODE -ne 0) { throw 'Could not update TCP Auto-Tuning level. Run Nova as administrator.' }
      & netsh interface tcp set heuristics $heuristics 2>$null | Out-Null
      & netsh interface tcp set global rss=$rss 2>$null | Out-Null
      Send-Result ([ordered]@{ before = $before; after = Get-TcpGlobalState })
    }
    'restorePoint' {
      Checkpoint-Computer -Description 'Nova Optimize' -RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop
      Send-Result ([ordered]@{ ok = $true; time = (Get-Date).ToUniversalTime().ToString('o') })
    }
    default { throw "Unknown bridge operation: $op" }
  }
} catch {
  $detail = $_.Exception.Message
  try {
    if ($_.InvocationInfo -and $_.InvocationInfo.ScriptLineNumber) {
      $detail = "$detail (line $($_.InvocationInfo.ScriptLineNumber))"
    }
  } catch { }
  Send-Result $detail $false
}

