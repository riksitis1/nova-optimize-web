#requires -Version 5.1
<#
  Creates a Desktop shortcut for Nova Optimize.
  The shortcut starts NovaOptimize.vbs with wscript.exe, so no console window
  appears. Run this file with PowerShell, or right-click it and choose
  "Run with PowerShell".
#>

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$launcher = Join-Path $root 'NovaOptimize.vbs'
$server = Join-Path $root 'server\server.js'
$icon = Join-Path $root 'public\assets\nova.ico'

if (-not (Test-Path -LiteralPath $launcher)) {
  throw 'NovaOptimize.vbs was not found. Keep this script inside the Nova Optimize folder.'
}
if (-not (Test-Path -LiteralPath $server)) {
  throw 'server\server.js was not found. The Nova Optimize folder looks incomplete.'
}

$desktop = [Environment]::GetFolderPath('Desktop')
$shortcutPath = Join-Path $desktop 'Nova Optimize.lnk'
$wscript = Join-Path $env:SystemRoot 'System32\wscript.exe'

$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $wscript
$shortcut.Arguments = '"' + $launcher + '"'
$shortcut.WorkingDirectory = $root
$shortcut.Description = 'Nova Optimize - free, local-first Windows gaming performance suite'
if (Test-Path -LiteralPath $icon) {
  $shortcut.IconLocation = "$icon,0"
}
$shortcut.Save()

Write-Host ''
Write-Host '  Created: ' -NoNewline
Write-Host $shortcutPath -ForegroundColor Green
Write-Host '  Double-click the new Desktop shortcut to start Nova.'
Write-Host ''
