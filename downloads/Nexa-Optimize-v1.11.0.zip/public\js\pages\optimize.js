import {
  state,
  icon,
  escapeHtml,
  formatBytes,
  toast,
  openModal,
  applyActions,
  undoAction,
  elevate,
  api,
  requestRender,
  hydrateIcons,
} from '../core.js';
import {
  severityBadge,
  riskBadge,
  impactBadge,
  rebootBadge,
  adminBadge,
  sectionHead,
  emptyState,
  metricRow,
} from '../ui.js';

function actionCard(action) {
  const locked = action.requiresAdmin && !state.snapshot?.admin;
  return `
    <article class="action-card ${action.appliedByNexa ? 'is-applied' : action.optimized ? 'is-optimized' : ''}">
      <div class="action-top">
        <h3>${escapeHtml(action.name)}</h3>
        ${action.risk === 'advanced' ? '<span class="badge advanced">Advanced</span>' : action.risk === 'caution' ? '<span class="badge amber">Caution</span>' : '<span class="badge green">Safe</span>'}
      </div>
      <p class="action-desc">${escapeHtml(action.description)}</p>
      ${action.risk !== 'safe' && action.note ? `<p class="action-note">${escapeHtml(action.note)}</p>` : ''}
      ${action.currentValue ? `<div class="action-current"><span>Current</span><strong class="mono">${escapeHtml(action.currentValue)}</strong></div>` : ''}
      <div class="action-foot">
        <span class="badge muted">${escapeHtml(action.category)}</span>
        ${impactBadge(action.impact)}
        ${action.requiresReboot ? rebootBadge() : ''}
        ${action.requiresAdmin ? adminBadge() : ''}
        ${action.appliedByNexa
          ? `<button class="button button-small" style="margin-left:auto" type="button" data-undo-action="${escapeHtml(action.id)}">${icon('undo')} Undo</button>`
          : action.optimized
            ? '<span class="action-status">' + icon('check') + ' Active</span>'
            : `<button class="button button-small ${locked ? '' : 'button-primary'}" style="margin-left:auto" type="button" data-apply-action="${escapeHtml(action.id)}">${locked ? icon('lock') + ' Admin' : icon('zap') + ' Apply'}</button>`}
      </div>
    </article>`;
}

function findingCard(finding) {
  return `
    <div class="finding">
      <div class="finding-sev ${escapeHtml(finding.severity)}">${icon(finding.severity === 'high' ? 'alert' : finding.severity === 'info' ? 'info' : 'zap')}</div>
      <div class="finding-body">
        <h3 class="finding-title">${escapeHtml(finding.title)} ${severityBadge(finding.severity)}</h3>
        <p class="finding-desc">${escapeHtml(finding.description)}</p>
        ${finding.detail ? `<p class="finding-detail">${escapeHtml(finding.detail)}</p>` : ''}
      </div>
      <div class="finding-side">
        ${finding.page ? `<button class="button button-small" type="button" data-nav="${escapeHtml(finding.page)}">${icon('arrow')} Review</button>` : ''}
        ${finding.link ? `<a class="button button-small" href="${escapeHtml(finding.link)}" target="_blank" rel="noreferrer">${icon('external')} ${escapeHtml(finding.linkLabel || 'Open')}</a>` : ''}
      </div>
    </div>`;
}

function appliedSection(scan) {
  const applied = scan.actions.filter((action) => action.appliedByNexa);
  if (!applied.length) return '';
  return `
    ${sectionHead('Applied by Nexa', 'Backed up and reversible. Undo one at a time or from the Activity page.')}
    <div class="card card-pad">
      <div class="chip-row">${applied.map((action) => `<button class="button button-small" type="button" data-undo-action="${escapeHtml(action.id)}">${icon('check')} ${escapeHtml(action.name)} · Undo</button>`).join('')}</div>
      <p class="small muted" style="margin:12px 0 0">Some changes need a restart to fully revert.</p>
    </div>`;
}

const WINDOWS_SETTINGS = [
  ['display-advancedgraphics', 'Graphics', 'Set the high-performance GPU per game. Compare Hardware-accelerated GPU scheduling on and off if Windows offers it.'],
  ['display-advanced', 'Refresh rate', 'Select the gaming monitor and confirm its refresh rate at your chosen resolution. A higher refresh rate changes display smoothness.'],
  ['powersleep', 'Power mode', 'On AC, compare Windows Best performance with your normal plan. Heat and power limits can change the result.'],
  ['gaming-gamedvr', 'Game captures', 'Review the recording buffer and capture settings. Turn off background recording if you do not use it.'],
  ['startupapps', 'Startup apps', 'Remove unnecessary launchers or sync tools from startup when they compete with your game.'],
  ['storagesense', 'Storage', 'Check free space. Use Windows Optimize Drives for scheduled SSD TRIM or HDD maintenance.'],
  ['windowsupdate-optionalupdates', 'Optional updates', 'Check driver updates if a game has rendering or stability issues. Prefer your PC or GPU vendor’s supported driver.'],
];

function windowsGamingCard() {
  const setup = state.windowsGamingSetup;
  const diagnostics = setup?.diagnostics;
  const display = diagnostics?.display;
  const memory = diagnostics?.memory;
  const commit = memory && memory.limitBytes > 0 ? Math.round(memory.committedBytes / memory.limitBytes * 100) : null;
  return `
    <div class="card card-pad" >
      <div class="card-header">
        <div><h2>Windows gaming setup</h2><p>Check display, power, memory, and background work before changing system settings.</p></div>
        <div class="card-actions">
          <button class="button button-small" data-action="scan-windows-gaming" type="button">${icon('scan')} ${setup ? 'Rescan Windows' : 'Scan Windows'}</button>
          <button class="button button-small button-primary" data-action="optimize-pc" type="button">${icon('spark')} Optimize PC</button>
        </div>
      </div>
      ${diagnostics ? `
        <div class="metrics-list">
          ${metricRow('Primary display', display ? `${display.width} × ${display.height} at ${display.currentHz} Hz · ${display.maxHz} Hz highest listed at this resolution` : 'Unavailable')}
          ${metricRow('Power', [setup.snapshot.power?.name, { Online: 'AC connected', Offline: 'On battery' }[diagnostics.powerLine] || 'AC status unavailable'].filter(Boolean).join(' · '))}
          ${metricRow('Memory commit', commit === null ? 'Unavailable' : `${formatBytes(memory.committedBytes)} / ${formatBytes(memory.limitBytes)} · ${commit}%`)}
          ${metricRow('Page file', memory?.automaticPagefile === true ? 'System managed' : memory?.automaticPagefile === false ? 'Manual configuration' : 'Unavailable')}
        </div>
        ${display?.maxHz > display?.currentHz ? '<p class="small">Windows lists a faster primary-display mode at this resolution. Verify it in Advanced display.</p>' : ''}
        ${commit >= 90 ? '<p class="small">Memory commit is near its limit. Close memory-heavy apps before playing.</p>' : ''}
        ${memory?.automaticPagefile === false ? '<p class="small">If games run out of memory, check Advanced system settings → Performance → Advanced → Virtual memory. System management lets Windows grow the page file as needed.</p>' : ''}
        ${diagnostics.syncApps.length ? `
          <h3>Cloud sync during play</h3>
          <p class="small muted">Lower CPU priority for running sync processes. This can slow sync. Restore it here or restart the sync app.</p>
          ${diagnostics.syncApps.map((app) => `
            <div class="finding">
              <div class="finding-body"><strong>${escapeHtml(app.label)}</strong><p class="small muted">${app.lowered} running at lowered priority</p></div>
              <div class="finding-side">
                ${app.eligible ? `<button class="button button-small" type="button" data-sync-lower="${escapeHtml(app.name)}">Lower priority</button>` : ''}
                ${app.lowered ? `<button class="button button-small" type="button" data-sync-restore="${escapeHtml(app.name)}">Restore priority</button>` : ''}
              </div>
            </div>`).join('')}
        ` : '<p class="small muted">No eligible cloud-sync apps are running.</p>'}
      ` : ''}
      <details class="game-tips" style="margin-top:12px">
        <summary>Windows settings for gaming</summary>
        <ul class="modal-list">
          ${WINDOWS_SETTINGS.map(([uri, name, description]) => `<li><a href="ms-settings:${uri}">${escapeHtml(name)}</a> · ${escapeHtml(description)}</li>`).join('')}
        </ul>
      </details>
    </div>`;
}

async function loadWindowsGamingSetup() {
  const setup = await api('/api/gaming/setup');
  state.windowsGamingSetup = setup;
  state.snapshot = setup.snapshot;
  state.scan = setup.scan;
  state.applied = setup.applied;
  return setup;
}

async function scanWindowsGaming(button) {
  if (button) button.disabled = true;
  try {
    await loadWindowsGamingSetup();
    requestRender();
  } catch (error) {
    toast('error', 'Could not scan Windows gaming settings', error.message);
  } finally {
    if (button) button.disabled = false;
  }
}

let optimizeScanInProgress = false;

export async function optimizePc(button) {
  if (optimizeScanInProgress) return;
  optimizeScanInProgress = true;
  const route = window.location.hash;
  const originalLabel = button.innerHTML;
  button.disabled = true;
  button.innerHTML = `${icon('scan')} Checking Windows…`;
  try {
    const setup = await loadWindowsGamingSetup();
    requestRender();
    if (route !== window.location.hash || document.getElementById('modal-root')?.firstElementChild) return;
    document.querySelector('[data-action="optimize-pc"]')?.focus();
    reviewWindowsGaming(setup);
  } catch (error) {
    toast('error', 'Could not check Windows settings', error.message);
  } finally {
    optimizeScanInProgress = false;
    button.disabled = false;
    button.innerHTML = originalLabel;
    hydrateIcons(button);
  }
}

function reviewWindowsGaming(setup) {
  if (!setup.candidates.length) {
    openModal({
      title: 'No changes available',
      body: '<p>Nexa found no applicable Windows gaming changes on this PC. You can still tune a game from the Games page.</p>',
      confirmLabel: 'Done',
      hideCancel: true,
    });
    return;
  }
  const isLocked = (action) => action.requiresAdmin && !setup.snapshot.admin;
  const canApply = setup.candidates.some((action) => !isLocked(action));
  openModal({
    title: 'Optimize PC',
    body: `<p>Review the Windows gaming settings available on this PC. Nexa saves the original settings so you can undo your changes from Windows.</p>
      <fieldset class="boost-list optimize-picks">
        <legend>Choose settings to apply</legend>
        ${setup.candidates.map((action) => {
          const locked = isLocked(action);
          return `<label class="boost-app optimize-pick">
            <input type="checkbox" value="${escapeHtml(action.id)}" ${locked ? 'disabled' : action.recommended ? 'checked' : ''}>
            <span class="boost-app-name"><strong>${escapeHtml(action.name)}</strong>
              <small>${escapeHtml(action.description)}</small>
              ${action.note ? `<small>${escapeHtml(action.note)}</small>` : ''}
              <small>${locked ? 'Administrator required' : action.recommended ? 'Recommended' : 'Optional'}</small>
            </span>
          </label>`;
        }).join('')}
      </fieldset>`,
    confirmLabel: canApply ? 'Apply selected settings' : 'Restart as administrator',
    onConfirm: canApply ? async () => {
      const ids = [...document.querySelectorAll('#modal-root .optimize-picks input:checked:not(:disabled)')].map((input) => input.value);
      if (!ids.length) throw new Error('Select at least one available setting.');
      const route = window.location.hash;
      const response = await api('/api/actions/apply', { method: 'POST', body: { ids, profile: 'gaming' } });
      state.snapshot = response.snapshot;
      state.scan = response.scan;
      state.applied = response.applied;
      state.history = null;
      state.windowsGamingSetup = null;
      requestRender();
      requestAnimationFrame(() => {
        if (route === window.location.hash && document.activeElement === document.body &&
            !document.getElementById('modal-root')?.firstElementChild) {
          document.querySelector('[data-action="optimize-pc"]')?.focus();
        }
      });

      const results = response.results;
      const changed = results.filter((result) => result.ok && !result.skipped).length;
      const failures = results.filter((result) => !result.ok);
      const detail = changed ? `${changed} changed. Undo from Windows → Applied by Nexa.` : 'No settings changed.';
      const title = changed ? 'Windows settings applied' : 'Settings already configured';
      if (failures.length || response.refreshWarning) {
        const names = new Map(setup.candidates.map((action) => [action.id, action.name]));
        const errors = failures.map((result) => `${names.get(result.id) || result.id} — ${result.error}`);
        const status = failures.length ? 'Could not apply all selected settings' : title;
        toast('warn', status, [detail, ...errors, response.refreshWarning].filter(Boolean).join(' · '), 9000);
      } else {
        toast(changed ? 'success' : 'info', title, detail);
      }
    } : elevate,
  });
}

function changeSyncPriority(name, restore) {
  const app = state.windowsGamingSetup?.diagnostics?.syncApps.find((item) => item.name === name);
  if (!app) return;
  openModal({
    title: `${restore ? 'Restore' : 'Lower'} ${app.label} CPU priority?`,
    body: restore ? '<p>Return the selected running sync processes to Normal priority.</p>'
      : '<p>Windows will give these running sync processes lower CPU priority during contention. File sync can take longer.</p>',
    confirmLabel: restore ? 'Restore priority' : 'Lower priority',
    onConfirm: async () => {
      const { result } = await api('/api/gaming/sync-priority', { method: 'POST', body: { names: [name], restore } });
      const detail = `${result.changed} changed · ${result.failed} failed`;
      toast(result.failed ? 'warn' : 'success', 'Cloud-sync CPU priority', detail);
      await scanWindowsGaming();
    },
  });
}

export function renderOptimize(mode = 'safe') {
  if (!state.scan) {
    return mode === 'safe' ? windowsGamingCard()
      : '<div class="page-loading"><div class="loading-orbit"></div><p>Scanning settings…</p></div>';
  }
  const scan = state.scan;
  const actionPool = scan.actions.filter((action) => action.applicable && (mode === 'advanced' ? action.risk === 'advanced' : action.risk !== 'advanced'));
  const safePool = actionPool.filter((action) => action.risk === 'safe');
  const cautionPool = actionPool.filter((action) => action.risk === 'caution');
  const safeReady = safePool.filter((action) => !action.optimized && !action.appliedByNexa);
  const cautionReady = cautionPool.filter((action) => !action.optimized && !action.appliedByNexa);
  const findings = scan.findings.filter((finding) => !finding.actionId);
  const primaryFindings = findings.filter((finding) => finding.severity !== 'info');
  const infoFindings = findings.filter((finding) => finding.severity === 'info');

  if (mode === 'advanced') {
    return `
      <div class="callout warn">${icon('alert')}<div><strong>Low-level Windows parameters.</strong> These settings modify kernel scheduling, input, and TCP behavior and are excluded from your main readiness score. Apply one change at a time and revert any setting that does not improve your workload.</div></div>
      ${sectionHead('Advanced controls', 'Low-level scheduling, input, and TCP stack parameters.', `<span class="badge muted">${actionPool.length} controls</span>`)}
      ${actionPool.length ? `<div class="action-grid">${actionPool.map((action) => actionCard(action)).join('')}</div>` : emptyState('check', 'Nothing to apply here', 'Every available setting in this section is already in the recommended state.')}
      ${appliedSection(scan)}
    `;
  }

  return `
    ${windowsGamingCard()}
    ${appliedSection(scan)}
    <details class="card disclosure" id="windows-controls" ${state.windowsControlsOpen ? 'open' : ''}>
      <summary>
        <span><strong>Individual Windows settings</strong><small>${safeReady.length + cautionReady.length} available to review</small></span>
        <span class="disclosure-chevron">${icon('chevron', 16)}</span>
      </summary>
      <div class="disclosure-body">
        ${safePool.length ? `<div class="action-grid">${safePool.map(actionCard).join('')}</div>` : ''}
        ${cautionPool.length ? `<div class="action-grid">${cautionPool.map(actionCard).join('')}</div>` : ''}
        <div><button class="button" type="button" data-action="restore-point">${icon('shield')} Create restore point</button></div>
      </div>
    </details>
    ${primaryFindings.length || infoFindings.length ? `
      <details class="card disclosure" id="windows-advisories" ${state.windowsAdvisoriesOpen ? 'open' : ''}>
        <summary>
          <span><strong>System advisories</strong><small>Hardware and Windows findings</small></span>
          <span class="disclosure-chevron">${icon('chevron', 16)}</span>
        </summary>
        <div class="disclosure-body">${[...primaryFindings, ...infoFindings].map(findingCard).join('')}</div>
      </details>` : ''}
  `;
}

async function confirmApplyOne(id) {
  const action = state.scan?.actions?.find((item) => item.id === id);
  if (!action) return;
  if (action.requiresAdmin && !state.snapshot?.admin) {
    openModal({
      title: 'Administrator access needed',
      body: `<p>${escapeHtml(action.name)} changes a system-wide setting. Restart Nexa with administrator rights to apply it.</p>`,
      confirmLabel: 'Restart as administrator',
      onConfirm: elevate,
    });
    return;
  }
  if (action.risk === 'safe') {
    try {
      const response = await applyActions([id]);
      const failed = (response.results || []).find((result) => !result.ok);
      if (failed) throw new Error(failed.error || 'Could not apply change.');
      toast('success', 'Applied', action.name);
    } catch (error) {
      toast('error', 'Could not apply change', error.message);
    }
    return;
  }
  openModal({
    title: action.name,
    body: `<p>${escapeHtml(action.description)}</p><ul class="modal-list"><li>${escapeHtml(action.note)}</li><li>Nexa records a backup first.</li>${action.requiresReboot ? '<li>A reboot is required for this change.</li>' : ''}</ul>`,
    confirmLabel: 'Apply change',
    danger: true,
    onConfirm: async () => {
      const response = await applyActions([id]);
      const failed = (response.results || []).find((result) => !result.ok);
      if (failed) throw new Error(failed.error || 'The change could not be applied.');
      toast('success', 'Change applied', action.name);
    },
  });
}

async function confirmUndo(id) {
  const action = state.scan?.actions?.find((item) => item.id === id);
  if (!action) return;
  try {
    await undoAction(id);
    toast('success', 'Restored original setting', action.name);
  } catch (error) {
    toast('error', 'Could not undo change', error.message);
  }
}

function createRestorePoint(button) {
  if (!state.snapshot?.admin) {
    openModal({
      title: 'Administrator access needed',
      body: '<p>Creating a Windows restore point requires administrator rights.</p>',
      confirmLabel: 'Restart as administrator',
      onConfirm: elevate,
    });
    return;
  }
  if (button) {
    button.disabled = true;
    button.innerHTML = `${icon('refresh')} Creating…`;
  }
  api('/api/restore-point', { method: 'POST', body: {} })
    .then(() => toast('success', 'Restore point created', 'Windows System Restore can now roll back system changes.'))
    .catch((error) => toast('error', 'Could not create restore point', error.message))
    .finally(() => {
      if (button) {
        button.disabled = false;
        button.innerHTML = `${icon('shield')} Create restore point`;
      }
    });
}

export function bindOptimize() {
  document.getElementById('windows-controls')?.addEventListener('toggle', (event) => {
    state.windowsControlsOpen = event.currentTarget.open;
  });
  document.getElementById('windows-advisories')?.addEventListener('toggle', (event) => {
    state.windowsAdvisoriesOpen = event.currentTarget.open;
  });

  document.querySelector('[data-action="scan-windows-gaming"]')?.addEventListener('click', (event) => scanWindowsGaming(event.currentTarget));
  document.querySelector('[data-action="optimize-pc"]')?.addEventListener('click', (event) => optimizePc(event.currentTarget));
  document.querySelectorAll('[data-sync-lower]').forEach((button) =>
    button.addEventListener('click', () => changeSyncPriority(button.dataset.syncLower, false)),
  );
  document.querySelectorAll('[data-sync-restore]').forEach((button) =>
    button.addEventListener('click', () => changeSyncPriority(button.dataset.syncRestore, true)),
  );

  document.querySelectorAll('[data-apply-action]').forEach((button) => {
    button.addEventListener('click', () => confirmApplyOne(button.getAttribute('data-apply-action')));
  });
  document.querySelectorAll('[data-undo-action]').forEach((button) => {
    button.addEventListener('click', () => confirmUndo(button.getAttribute('data-undo-action')));
  });
  document.querySelectorAll('[data-action="restore-point"]').forEach((button) => {
    button.addEventListener('click', () => createRestorePoint(button));
  });
}
