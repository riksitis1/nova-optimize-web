import {
  state,
  icon,
  escapeHtml,
  toast,
  openModal,
  applyActions,
  undoAction,
  elevate,
  api,
  requestRender,
} from '../core.js';
import {
  scoreRing,
  severityBadge,
  riskBadge,
  impactBadge,
  rebootBadge,
  adminBadge,
  sectionHead,
  emptyState,
  metricRow,
} from '../ui.js';

function categoryBars(scan) {
  return Object.entries(scan.categoryScores || {}).map(([category, score]) => `
    <div style="display:flex;align-items:center;gap:10px;margin-top:7px">
      <span class="small muted" style="width:86px">${escapeHtml(category)}</span>
      <div class="meter" style="flex:1"><span style="width:${score}%;background:${score >= 85 ? 'var(--lime)' : score >= 65 ? 'var(--amber)' : 'var(--red)'}"></span></div>
      <span class="mono" style="width:28px;text-align:right">${score}</span>
    </div>`).join('');
}

function summaryCard(scan, mode, actionPool = []) {
  const advActive = actionPool.filter((action) => action.optimized || action.appliedByNova).length;
  const advReady = actionPool.length - advActive;
  return `
    <div class="card card-pad">
      <div style="display:grid;grid-template-columns:auto minmax(0,1fr);gap:24px;align-items:center">
        ${scoreRing(scan.score, scan.potentialScore, 158)}
        <div>
          <div style="display:flex;flex-wrap:wrap;align-items:center;gap:7px">
            <span class="badge lime">${icon('spark')} ${escapeHtml(scan.rank)}</span>
            ${mode === 'advanced'
              ? `<span class="badge advanced">${advReady} optional</span><span class="badge muted">${advActive} active</span>`
              : `<span class="badge muted">${scan.counts.issues} issues</span><span class="badge muted">${scan.counts.optimized} already optimized</span>`}
          </div>
          <p class="muted" style="margin:10px 0 14px;font-size:12px;line-height:1.55">${escapeHtml(mode === 'advanced' ? 'Optional low-level Windows parameters. These do not affect your Nova readiness score.' : scan.summary)}</p>
          ${categoryBars(scan)}
          <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:18px">
            ${mode === 'advanced'
              ? `<span class="badge advanced">${icon('beaker')} Expert controls</span><span class="small muted" style="align-self:center">Changes here are backed up and reversible, but test one at a time.</span>`
              : `<button class="button button-primary" type="button" data-action="apply-safe">${icon('zap')} Apply safe fixes</button>
                 <button class="button" type="button" data-action="restore-point">${icon('shield')} Create restore point</button>`}
          </div>
        </div>
      </div>
    </div>`;
}

function actionCard(action) {
  const locked = action.requiresAdmin && !state.snapshot?.admin;
  return `
    <article class="action-card ${action.appliedByNova ? 'is-applied' : action.optimized ? 'is-optimized' : ''}">
      <div class="action-top">
        <h3>${escapeHtml(action.name)}</h3>
        ${action.risk === 'advanced' ? '<span class="badge advanced">Advanced</span>' : action.risk === 'caution' ? '<span class="badge amber">Caution</span>' : '<span class="badge green">Safe</span>'}
      </div>
      <p class="action-desc">${escapeHtml(action.description)}</p>
      <p class="action-note">${escapeHtml(action.note)}</p>
      ${action.currentValue ? `<div class="action-current"><span>Current state</span><strong class="mono">${escapeHtml(action.currentValue)}</strong></div>` : ''}
      <div class="action-foot">
        <span class="badge muted">${escapeHtml(action.category)}</span>
        ${impactBadge(action.impact)}
        ${action.requiresReboot ? rebootBadge() : ''}
        ${action.requiresAdmin ? adminBadge() : ''}
        ${action.appliedByNova
          ? `<button class="button button-small" style="margin-left:auto" type="button" data-undo-action="${escapeHtml(action.id)}">${icon('undo')} Undo</button>`
          : action.optimized
            ? '<span class="action-status">' + icon('check') + ' Already on</span>'
            : `<button class="button button-small ${locked ? '' : 'button-primary'}" style="margin-left:auto" type="button" data-apply-action="${escapeHtml(action.id)}">${locked ? icon('lock') + ' Admin required' : icon('zap') + ' Apply'}</button>`}
      </div>
    </article>`;
}

function findingCard(finding) {
  return `
    <div class="finding">
      <div class="finding-sev ${escapeHtml(finding.severity)}">${icon(finding.severity === 'high' ? 'alert' : finding.severity === 'info' ? 'info' : 'zap')}</div>
      <div class="finding-body">
        <h3 class="finding-title">${escapeHtml(finding.title)} ${severityBadge(finding.severity)}</h3>
        <p class="finding-desc">${escapeHtml(finding.description)}</p>
        ${finding.detail ? `<p class="finding-detail">${escapeHtml(finding.detail)}</p>` : ''}
      </div>
      <div class="finding-side">
        ${finding.page ? `<button class="button button-small" type="button" data-nav="${escapeHtml(finding.page)}">${icon('arrow')} Review</button>` : ''}
        ${finding.link ? `<a class="button button-small" href="${escapeHtml(finding.link)}" target="_blank" rel="noreferrer">${icon('external')} ${escapeHtml(finding.linkLabel || 'Open')}</a>` : ''}
      </div>
    </div>`;
}

function appliedSection(scan) {
  const applied = scan.actions.filter((action) => action.appliedByNova);
  if (!applied.length) return '';
  return `
    ${sectionHead('Applied by Nova', 'Backed up and reversible. Undo one at a time or from the Activity page.')}
    <div class="card card-pad">
      <div class="chip-row">${applied.map((action) => `<span class="badge lime">${icon('check')} ${escapeHtml(action.name)}</span>`).join('')}</div>
      <p class="small muted" style="margin:12px 0 0">Some changes need a restart to fully revert.</p>
    </div>`;
}

export function renderOptimize(mode = 'safe') {
  if (!state.scan) {
    return '<div class="page-loading"><div class="loading-orbit"></div><p>Scanning settings…</p></div>';
  }
  const scan = state.scan;
  const actionPool = scan.actions.filter((action) => action.applicable && (mode === 'advanced' ? action.risk === 'advanced' : action.risk !== 'advanced'));
  const safePool = actionPool.filter((action) => action.risk === 'safe');
  const cautionPool = actionPool.filter((action) => action.risk === 'caution');
  const safeReady = safePool.filter((action) => !action.optimized && !action.appliedByNova);
  const cautionReady = cautionPool.filter((action) => !action.optimized && !action.appliedByNova);
  const findings = scan.findings.filter((finding) => !finding.actionId);
  const primaryFindings = findings.filter((finding) => finding.severity !== 'info');
  const infoFindings = findings.filter((finding) => finding.severity === 'info');

  if (mode === 'advanced') {
    return `
      ${summaryCard(scan, mode, actionPool)}
      <div class="callout warn" style="margin-top:14px">${icon('alert')}<div><strong>Advanced tweaks are not magic.</strong> These are legacy or situational Windows settings. They do not affect your readiness score. Test one at a time, and undo anything that makes your games or desktop feel worse.</div></div>
      ${sectionHead('Advanced controls', 'For people who want to tune low-level scheduling, input and TCP behavior.', `<span class="badge muted">${actionPool.length} controls</span>`)}
      ${actionPool.length ? `<div class="action-grid">${actionPool.map((action) => actionCard(action)).join('')}</div>` : emptyState('check', 'Nothing to apply here', 'Every available setting in this section is already in the recommended state.')}
      ${appliedSection(scan)}
    `;
  }

  return `
    ${summaryCard(scan, mode, actionPool)}
    ${sectionHead('Safe optimizations', 'Recommended, reversible changes with no side effects for normal use.', `<span class="badge muted">${safeReady.length} ready</span>`)}
    ${safePool.length ? `<div class="action-grid">${safePool.map((action) => actionCard(action)).join('')}</div>` : emptyState('check', 'Nothing to apply here', 'Every safe setting is already in the recommended state.')}
    ${cautionPool.length ? `
      ${sectionHead('Situational optimizations', 'Worth enabling on most gaming PCs, but review the note first — these are not included in "Apply safe fixes".', `<span class="badge amber">${cautionReady.length} review</span>`)}
      <div class="action-grid">${cautionPool.map((action) => actionCard(action)).join('')}</div>
    ` : ''}
    ${primaryFindings.length ? `${sectionHead('Other findings', 'These need a decision, not a one-click tweak.')}<div>${primaryFindings.map(findingCard).join('')}</div>` : ''}
    ${infoFindings.length ? `${sectionHead('Worth knowing', 'Hardware and OS context — not a problem to fix.')}<div>${infoFindings.map(findingCard).join('')}</div>` : ''}
    ${appliedSection(scan)}
    <p class="small muted" style="margin-top:24px;line-height:1.6">Nova only counts changes it can back up. Windows updates, driver installs and hardware upgrades are never automatic.</p>
  `;
}

function confirmApplyOne(id) {
  const action = state.scan?.actions?.find((item) => item.id === id);
  if (!action) return;
  if (action.requiresAdmin && !state.snapshot?.admin) {
    openModal({
      title: 'Administrator access needed',
      body: `<p>${escapeHtml(action.name)} changes a system-wide setting. Restart Nova with administrator rights to apply it.</p>`,
      confirmLabel: 'Restart as administrator',
      onConfirm: elevate,
    });
    return;
  }
  openModal({
    title: action.name,
    body: `<p>${escapeHtml(action.description)}</p><ul class="modal-list"><li>${escapeHtml(action.note)}</li><li>Nova records a backup first.</li>${action.requiresReboot ? '<li>A reboot is required for this change.</li>' : ''}</ul>`,
    confirmLabel: 'Apply change',
    danger: action.risk !== 'safe',
    onConfirm: async () => {
      const response = await applyActions([id]);
      const failed = (response.results || []).find((result) => !result.ok);
      if (failed) throw new Error(failed.error || 'The change could not be applied.');
      toast('success', 'Change applied', action.name);
    },
  });
}

function confirmUndo(id) {
  const action = state.scan?.actions?.find((item) => item.id === id);
  if (!action) return;
  openModal({
    title: `Undo ${action.name}?`,
    body: '<p>Nova will restore the value it backed up before applying this change. Some settings need a reboot or reconnect to fully revert.</p>',
    confirmLabel: 'Undo change',
    danger: true,
    onConfirm: async () => {
      await undoAction(id);
      toast('success', 'Change undone', action.name);
    },
  });
}

function applySafe() {
  const candidates = (state.scan?.actions || []).filter(
    (action) => action.applicable && action.risk === 'safe' && !action.optimized && !action.appliedByNova,
  );
  if (!candidates.length) {
    toast('info', 'Nothing to apply', 'Every safe optimization is already active.');
    return;
  }
  const blocked = !state.snapshot?.admin ? candidates.filter((action) => action.requiresAdmin) : [];
  const available = candidates.filter((action) => !blocked.includes(action));
  if (!available.length) {
    openModal({
      title: 'Administrator access needed',
      body: '<p>The remaining safe fixes change system-wide settings. Restart Nova with administrator rights to continue.</p>',
      confirmLabel: 'Restart as administrator',
      onConfirm: elevate,
    });
    return;
  }
  openModal({
    title: `Apply ${available.length} safe fix${available.length === 1 ? '' : 's'}?`,
    body: `<p>Nova will back up each setting before changing it. You can undo everything from Activity.</p><ul class="modal-list">${available.map((action) => `<li>${escapeHtml(action.name)}</li>`).join('')}</ul>${blocked.length ? `<p class="small" style="margin-top:10px">${blocked.length} fix${blocked.length === 1 ? '' : 'es'} skipped — administrator access required.</p>` : ''}`,
    confirmLabel: 'Apply safe fixes',
    onConfirm: async () => {
      const response = await applyActions(available.map((action) => action.id));
      const failed = (response.results || []).filter((result) => !result.ok);
      if (failed.length) {
        toast('warn', 'Some changes were skipped', failed.map((result) => result.error).join(' · '));
      } else {
        toast('success', 'Safe fixes applied', `${available.length} settings updated. Reboot if Windows asks.`);
      }
    },
  });
}

function createRestorePoint(button) {
  if (!state.snapshot?.admin) {
    openModal({
      title: 'Administrator access needed',
      body: '<p>Creating a Windows restore point requires administrator rights.</p>',
      confirmLabel: 'Restart as administrator',
      onConfirm: elevate,
    });
    return;
  }
  if (button) {
    button.disabled = true;
    button.innerHTML = `${icon('refresh')} Creating…`;
  }
  api('/api/restore-point', { method: 'POST', body: {} })
    .then(() => toast('success', 'Restore point created', 'Windows System Restore can now roll back system changes.'))
    .catch((error) => toast('error', 'Could not create restore point', error.message))
    .finally(() => {
      if (button) {
        button.disabled = false;
        button.innerHTML = `${icon('shield')} Create restore point`;
      }
    });
}

export function bindOptimize() {
  document.querySelectorAll('[data-apply-action]').forEach((button) => {
    button.addEventListener('click', () => confirmApplyOne(button.getAttribute('data-apply-action')));
  });
  document.querySelectorAll('[data-undo-action]').forEach((button) => {
    button.addEventListener('click', () => confirmUndo(button.getAttribute('data-undo-action')));
  });
  document.querySelectorAll('[data-action="apply-safe"]').forEach((button) => {
    button.addEventListener('click', applySafe);
  });
  document.querySelectorAll('[data-action="restore-point"]').forEach((button) => {
    button.addEventListener('click', () => createRestorePoint(button));
  });
}
