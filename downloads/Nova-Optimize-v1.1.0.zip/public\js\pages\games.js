import {
  state,
  icon,
  escapeHtml,
  toast,
  openModal,
  api,
  requestRender,
  copyText,
} from '../core.js';
import { sectionHead, impactBadge, emptyState } from '../ui.js';

function selectionFor(game) {
  state.gameSelections = state.gameSelections || {};
  if (!state.gameSelections[game.id]) {
    state.gameSelections[game.id] = new Set(
      game.settings.filter((setting) => setting.defaultOn && !setting.optimized).map((setting) => setting.id),
    );
  }
  return state.gameSelections[game.id];
}

function replaceGame(next) {
  if (!next || !Array.isArray(state.games)) return;
  state.games = state.games.map((game) => (game.id === next.id ? next : game));
}

function statusBadge(game) {
  if (game.running) return `<span class="badge amber">${icon('alert')} Running. Close it first</span>`;
  if (!game.installed) return '<span class="badge muted">Config not found</span>';
  if (game.applied) return `<span class="badge lime">${icon('check')} ${game.applied.settingIds.length} applied · Backed up</span>`;
  return '<span class="badge green">Ready</span>';
}

function settingRow(game, setting, selected, locked) {
  const current = setting.current === null || setting.current === undefined ? 'not set' : setting.current;
  const values = setting.optimized
    ? `<span class="game-ok">${icon('check')} ${escapeHtml(setting.recommended)}</span>`
    : `<span class="game-from">${escapeHtml(current)}</span><span class="game-arrow">${icon('arrow')}</span><span class="game-to">${escapeHtml(setting.recommended)}</span>`;
  const restoreOneBtn = setting.appliedByNova
    ? `<button class="button button-small button-ghost" type="button" data-game-restore-one="${escapeHtml(game.id)}:${escapeHtml(setting.id)}" ${game.running ? 'disabled' : ''} title="Restore this setting back to ${escapeHtml(setting.original ?? 'its original value')}">${icon('undo')} Restore</button>`
    : '';
  return `
    <div class="game-setting ${setting.optimized ? 'is-optimal' : ''} ${locked ? 'is-locked' : ''}">
      <label style="display:contents;cursor:inherit">
        <input type="checkbox" data-game-setting="${escapeHtml(game.id)}:${escapeHtml(setting.id)}" ${selected.has(setting.id) ? 'checked' : ''} ${locked ? 'disabled' : ''}>
        <span class="game-check" aria-hidden="true">${icon('check', 12)}</span>
        <span class="game-setting-main">
          <strong>
            ${escapeHtml(setting.label)}
            ${impactBadge(setting.impact)}
            ${setting.appliedByNova ? `<span class="badge lime">Backed up${setting.original !== null && setting.original !== undefined ? ` (${escapeHtml(setting.original)})` : ''}</span>` : ''}
          </strong>
          <small>${escapeHtml(setting.description)}</small>
        </span>
      </label>
      <span class="game-values mono">
        ${values}
        ${restoreOneBtn}
      </span>
    </div>`;
}

function gameCard(game) {
  const selected = selectionFor(game);
  const locked = !game.installed || game.running;
  const count = game.settings.filter((setting) => selected.has(setting.id)).length;
  const hasBackup = Boolean(game.applied && game.applied.settingIds?.length);
  const tips = (game.tips || []).map((tip) => `<li>${escapeHtml(tip)}</li>`).join('');
  return `
    <article class="card game-card" data-game="${escapeHtml(game.id)}">
      <header class="game-head">
        <div class="game-mark">${icon('gamepad', 22)}</div>
        <div class="game-title">
          <h3>${escapeHtml(game.name)}</h3>
          <p>${escapeHtml(game.tagline)}</p>
        </div>
        ${statusBadge(game)}
      </header>
      ${game.installed
        ? `<p class="game-file mono">${escapeHtml(game.fileLabel)}${game.files.length > 1 ? ` · ${game.files.length} Steam accounts` : ''}${hasBackup ? ` · Backup ready (${game.applied.settingIds.length} setting${game.applied.settingIds.length === 1 ? '' : 's'})` : ''}</p>`
        : `<p class="game-file game-missing">Nova looks for <span class="mono">${escapeHtml(game.expectedPath || game.fileLabel)}</span>. Launch ${escapeHtml(game.name)} once so it creates its config, then re-check.</p>`}
      <div class="game-tools">
        <span class="small muted">Choose what Nova changes</span>
        <span class="game-tool-links">
          <button class="link-button" type="button" data-game-pick="${escapeHtml(game.id)}:recommended" ${locked ? 'disabled' : ''}>Recommended</button>
          <button class="link-button" type="button" data-game-pick="${escapeHtml(game.id)}:all" ${locked ? 'disabled' : ''}>All</button>
          <button class="link-button" type="button" data-game-pick="${escapeHtml(game.id)}:none" ${locked ? 'disabled' : ''}>None</button>
        </span>
      </div>
      <div class="game-settings">
        ${game.settings.map((setting) => settingRow(game, setting, selected, locked)).join('')}
      </div>
      ${game.launchOptions ? `
        <div class="game-launch">
          <span class="small muted">Suggested Steam launch options</span>
          <code class="mono">${escapeHtml(game.launchOptions)}</code>
          <button class="button button-small" type="button" data-game-copy="${escapeHtml(game.launchOptions)}">${icon('copy')} Copy</button>
        </div>` : ''}
      <details class="game-tips">
        <summary>Before you apply or restore</summary>
        <ul>${tips}</ul>
      </details>
      <footer class="game-foot">
        <button class="button button-primary" type="button" data-game-apply="${escapeHtml(game.id)}" ${locked || !count ? 'disabled' : ''}>${icon('zap')} <span data-game-apply-label="${escapeHtml(game.id)}">Apply ${count} setting${count === 1 ? '' : 's'}</span></button>
        <button class="button" type="button" data-game-restore="${escapeHtml(game.id)}" ${!hasBackup || game.running ? 'disabled' : ''} title="${hasBackup ? 'Restore all original settings for this game' : 'Apply settings first — Nova will back up your original values so you can restore them anytime'}">${icon('undo')} Restore original${hasBackup ? ` (${game.applied.settingIds.length})` : ''}</button>
      </footer>
    </article>`;
}

export function renderGames() {
  if (!Array.isArray(state.games)) {
    return '<div class="page-loading"><div class="loading-orbit"></div><p>Looking for your games…</p></div>';
  }
  const anyApplied = state.games.some((g) => g.applied && g.applied.settingIds?.length);
  const actionsHtml = `
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="button button-small" type="button" data-action="restore-all-games" ${anyApplied ? '' : 'disabled'} title="Restore all games back to their original settings">${icon('undo')} Restore all games</button>
      <button class="button button-small" type="button" data-action="recheck-games">${icon('refresh')} Re-check games</button>
    </div>`;
  return `
    ${sectionHead('Game profiles', 'One click to the best-performance settings for the games you play. Choose which settings to apply, and restore individual settings or the whole game anytime.', actionsHtml)}
    <div class="callout" style="margin-bottom:14px">${icon('shield')}<div><strong>Automatic backup &amp; 1-click restore.</strong> Nova backs up your original config file before changing anything. You can click <em>Restore</em> on any individual setting row or <em>Restore original</em> at the bottom of a game card to put your previous settings right back.</div></div>
    <div class="game-grid">${state.games.map(gameCard).join('')}</div>
    ${state.games.some((game) => game.installed) ? '' : emptyState('gamepad', 'No supported games found yet', 'Install and launch Fortnite, Counter-Strike 2 or Minecraft once, then press Re-check games.')}
    <p class="small muted" style="margin:14px 0 0">More games are coming in future updates. Settings are the same ones you can change in each game's video menu, just applied and backed up in one step.</p>
  `;
}

function updateApplyButton(gameId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  const count = selectionFor(game).size;
  const button = document.querySelector(`[data-game-apply="${gameId}"]`);
  const label = document.querySelector(`[data-game-apply-label="${gameId}"]`);
  if (label) label.textContent = `Apply ${count} setting${count === 1 ? '' : 's'}`;
  if (button) button.disabled = !count || !game.installed || game.running;
}

async function applySelected(gameId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  const ids = Array.from(selectionFor(game));
  if (!ids.length) {
    toast('info', 'Nothing selected', 'Tick at least one setting to apply.');
    return;
  }
  const button = document.querySelector(`[data-game-apply="${gameId}"]`);
  if (button) button.disabled = true;
  try {
    const data = await api('/api/games/apply', { method: 'POST', body: { gameId, settingIds: ids } });
    replaceGame(data.game);
    state.history = null;
    toast('success', `${game.name} is tuned`, `${data.result.applied.length} setting${data.result.applied.length === 1 ? '' : 's'} applied. Original values are backed up and can be restored anytime.`);
  } catch (error) {
    toast('error', `Could not tune ${game.name}`, error.message);
  } finally {
    requestRender();
  }
}

async function restoreSingleSetting(gameId, settingId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  const setting = game.settings.find((item) => item.id === settingId);
  try {
    const data = await api('/api/games/revert', {
      method: 'POST',
      body: { gameId, settingIds: [settingId] },
    });
    replaceGame(data.game);
    state.history = null;
    toast('success', `${setting ? setting.label : 'Setting'} restored`, `Restored in ${game.name}.`);
  } catch (error) {
    toast('error', `Could not restore setting`, error.message);
  } finally {
    requestRender();
  }
}

function restoreGame(gameId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  openModal({
    title: `Restore ${game.name} settings?`,
    body: `<p>Nova will put back the original values it backed up (${game.applied?.settingIds.length || 0} setting${game.applied?.settingIds.length === 1 ? '' : 's'}). Anything else you changed in the game since then is kept.</p>`,
    confirmLabel: 'Restore original settings',
    onConfirm: async () => {
      const data = await api('/api/games/revert', { method: 'POST', body: { gameId } });
      replaceGame(data.game);
      state.gameSelections = state.gameSelections || {};
      delete state.gameSelections[gameId];
      state.history = null;
      toast('success', `${game.name} restored`, 'Your original settings are back.');
      requestRender();
    },
  });
}

function restoreAllGames() {
  const activeGames = (state.games || []).filter((g) => g.applied && g.applied.settingIds?.length);
  if (!activeGames.length) return;
  openModal({
    title: 'Restore all game settings?',
    body: `<p>Nova will restore original backed-up settings for <strong>${escapeHtml(activeGames.map((g) => g.name).join(', '))}</strong>.</p>`,
    confirmLabel: 'Restore all games',
    onConfirm: async () => {
      for (const game of activeGames) {
        const data = await api('/api/games/revert', { method: 'POST', body: { gameId: game.id } });
        replaceGame(data.game);
        if (state.gameSelections) delete state.gameSelections[game.id];
      }
      state.history = null;
      toast('success', 'All game settings restored', 'Every game is back to its original configuration.');
      requestRender();
    },
  });
}

export async function loadGames() {
  const data = await api('/api/games');
  state.games = data.games;
}

export function bindGames() {
  document.querySelectorAll('[data-game-setting]').forEach((input) => {
    input.addEventListener('change', () => {
      const [gameId, settingId] = input.getAttribute('data-game-setting').split(':');
      const game = state.games?.find((item) => item.id === gameId);
      if (!game) return;
      const selected = selectionFor(game);
      if (input.checked) selected.add(settingId);
      else selected.delete(settingId);
      updateApplyButton(gameId);
    });
  });
  document.querySelectorAll('[data-game-pick]').forEach((button) => {
    button.addEventListener('click', () => {
      const [gameId, mode] = button.getAttribute('data-game-pick').split(':');
      const game = state.games?.find((item) => item.id === gameId);
      if (!game) return;
      const next = new Set();
      for (const setting of game.settings) {
        if (mode === 'all' || (mode === 'recommended' && setting.defaultOn && !setting.optimized)) next.add(setting.id);
      }
      state.gameSelections[gameId] = next;
      requestRender();
    });
  });
  document.querySelectorAll('[data-game-apply]').forEach((button) => {
    button.addEventListener('click', () => applySelected(button.getAttribute('data-game-apply')));
  });
  document.querySelectorAll('[data-game-restore]').forEach((button) => {
    button.addEventListener('click', () => restoreGame(button.getAttribute('data-game-restore')));
  });
  document.querySelectorAll('[data-game-restore-one]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const [gameId, settingId] = button.getAttribute('data-game-restore-one').split(':');
      restoreSingleSetting(gameId, settingId);
    });
  });
  document.querySelectorAll('[data-action="restore-all-games"]').forEach((button) => {
    button.addEventListener('click', restoreAllGames);
  });
  document.querySelectorAll('[data-game-copy]').forEach((button) => {
    button.addEventListener('click', () => copyText(button.getAttribute('data-game-copy')));
  });
  document.querySelectorAll('[data-action="recheck-games"]').forEach((button) => {
    button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        await loadGames();
        toast('success', 'Games re-checked');
      } catch (error) {
        toast('error', 'Could not check games', error.message);
      }
      requestRender();
    });
  });
}
