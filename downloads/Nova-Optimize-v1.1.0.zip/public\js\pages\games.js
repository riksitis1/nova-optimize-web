import {
  state,
  icon,
  escapeHtml,
  toast,
  openModal,
  api,
  requestRender,
  copyText,
} from '../core.js';
import { sectionHead, impactBadge, emptyState } from '../ui.js';

function selectionFor(game) {
  state.gameSelections = state.gameSelections || {};
  if (!state.gameSelections[game.id]) {
    state.gameSelections[game.id] = new Set(
      game.settings.filter((setting) => setting.defaultOn && !setting.optimized).map((setting) => setting.id),
    );
  }
  return state.gameSelections[game.id];
}

function replaceGame(next) {
  if (!next || !Array.isArray(state.games)) return;
  state.games = state.games.map((game) => (game.id === next.id ? next : game));
}

function statusBadge(game) {
  if (game.running) return `<span class="badge amber">${icon('alert')} Running. Close it first</span>`;
  if (!game.installed) return '<span class="badge muted">Config not found</span>';
  if (game.applied) return `<span class="badge lime">${icon('check')} ${game.applied.settingIds.length} applied · Backed up</span>`;
  return '<span class="badge green">Ready</span>';
}

function settingRow(game, setting, selected, locked) {
  const current = setting.current === null || setting.current === undefined ? 'not set' : setting.current;
  const values = setting.optimized
    ? `<span class="game-ok">${icon('check')} ${escapeHtml(setting.recommended)}</span>`
    : `<span class="game-from">${escapeHtml(current)}</span><span class="game-arrow">${icon('arrow')}</span><span class="game-to">${escapeHtml(setting.recommended)}</span>`;
  const restoreOneBtn = setting.appliedByNova
    ? `<button class="button button-small button-ghost game-restore-inline" type="button" data-game-restore-one="${escapeHtml(game.id)}:${escapeHtml(setting.id)}" ${game.running ? 'disabled' : ''} title="Restore this setting to ${escapeHtml(setting.original ?? 'its original value')}">${icon('undo')} Restore</button>`
    : '';
  return `
    <div class="game-setting ${setting.optimized ? 'is-optimal' : ''} ${locked ? 'is-locked' : ''}">
      <label class="game-setting-label">
        <input type="checkbox" data-game-setting="${escapeHtml(game.id)}:${escapeHtml(setting.id)}" ${selected.has(setting.id) ? 'checked' : ''} ${locked ? 'disabled' : ''}>
        <span class="game-check" aria-hidden="true">${icon('check', 12)}</span>
        <span class="game-setting-main">
          <span class="game-setting-top">
            <strong>
              ${escapeHtml(setting.label)}
              ${impactBadge(setting.impact)}
              ${setting.appliedByNova ? `<span class="badge lime">Backed up${setting.original !== null && setting.original !== undefined ? `: ${escapeHtml(setting.original)}` : ''}</span>` : ''}
            </strong>
            <span class="game-values mono">${values}</span>
          </span>
          <small>${escapeHtml(setting.description)}</small>
        </span>
      </label>
      ${restoreOneBtn ? `<div class="game-setting-actions">${restoreOneBtn}</div>` : ''}
    </div>`;
}

function gameCard(game) {
  const selected = selectionFor(game);
  const locked = !game.installed || game.running;
  const count = game.settings.filter((setting) => selected.has(setting.id)).length;
  const hasBackup = Boolean(game.applied && game.applied.settingIds?.length);
  const tips = (game.tips || []).map((tip) => `<li>${escapeHtml(tip)}</li>`).join('');
  return `
    <article class="card game-card" data-game="${escapeHtml(game.id)}">
      <header class="game-head">
        <div class="game-mark">${icon('gamepad', 20)}</div>
        <div class="game-title">
          <div class="game-title-row">
            <h3>${escapeHtml(game.name)}</h3>
            ${statusBadge(game)}
          </div>
          <p>${escapeHtml(game.tagline)}</p>
        </div>
        <div class="game-tools">
          <span class="small muted">Select:</span>
          <span class="game-tool-links">
            <button class="link-button" type="button" data-game-pick="${escapeHtml(game.id)}:recommended" ${locked ? 'disabled' : ''}>Recommended</button>
            <button class="link-button" type="button" data-game-pick="${escapeHtml(game.id)}:all" ${locked ? 'disabled' : ''}>All</button>
            <button class="link-button" type="button" data-game-pick="${escapeHtml(game.id)}:none" ${locked ? 'disabled' : ''}>None</button>
          </span>
        </div>
      </header>
      ${game.installed
        ? `<div class="game-file-bar"><span class="mono">${escapeHtml(game.fileLabel)}</span>${game.files.length > 1 ? `<span class="badge muted">${game.files.length} Steam accounts</span>` : ''}${hasBackup ? `<span class="badge lime">Backup active (${game.applied.settingIds.length} setting${game.applied.settingIds.length === 1 ? '' : 's'})</span>` : ''}</div>`
        : `<p class="game-file game-missing">Config path: <span class="mono">${escapeHtml(game.expectedPath || game.fileLabel)}</span>. Launch ${escapeHtml(game.name)} once to generate its config file, then click Re-check games.</p>`}
      <div class="game-settings">
        ${game.settings.map((setting) => settingRow(game, setting, selected, locked)).join('')}
      </div>
      ${game.launchOptions ? `
        <div class="game-launch">
          <span class="small muted">Optional Steam launch parameters</span>
          <code class="mono">${escapeHtml(game.launchOptions)}</code>
          <button class="button button-small" type="button" data-game-copy="${escapeHtml(game.launchOptions)}">${icon('copy')} Copy</button>
        </div>` : ''}
      <footer class="game-foot">
        <div class="game-foot-buttons">
          <button class="button button-primary" type="button" data-game-apply="${escapeHtml(game.id)}" ${locked || !count ? 'disabled' : ''}>${icon('zap')} <span data-game-apply-label="${escapeHtml(game.id)}">Apply ${count} setting${count === 1 ? '' : 's'}</span></button>
          <button class="button" type="button" data-game-restore="${escapeHtml(game.id)}" ${!hasBackup || game.running ? 'disabled' : ''} title="${hasBackup ? 'Restore all original backed-up settings for this game' : 'Apply settings first to create a restore point for this game'}">${icon('undo')} Restore original${hasBackup ? ` (${game.applied.settingIds.length})` : ''}</button>
        </div>
        <details class="game-tips">
          <summary>Notes &amp; behavior</summary>
          <ul>${tips}</ul>
        </details>
      </footer>
    </article>`;
}

export function renderGames() {
  if (!Array.isArray(state.games)) {
    return '<div class="page-loading"><div class="loading-orbit"></div><p>Scanning game configurations…</p></div>';
  }
  const activeFilter = state.gameFilter || 'all';
  const visibleGames = activeFilter === 'all'
    ? state.games
    : state.games.filter((g) => g.id === activeFilter);
  const anyApplied = state.games.some((g) => g.applied && g.applied.settingIds?.length);
  const actionsHtml = `
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="button button-small" type="button" data-action="restore-all-games" ${anyApplied ? '' : 'disabled'} title="Restore all games back to their original settings">${icon('undo')} Restore all games</button>
      <button class="button button-small" type="button" data-action="recheck-games">${icon('refresh')} Re-check games</button>
    </div>`;
  const filterTabs = `
    <div class="game-filter-bar" role="tablist" aria-label="Filter games">
      <button type="button" class="tab ${activeFilter === 'all' ? 'active' : ''}" data-game-filter="all">All games (${state.games.length})</button>
      ${state.games.map((g) => `
        <button type="button" class="tab ${activeFilter === g.id ? 'active' : ''}" data-game-filter="${escapeHtml(g.id)}">
          ${escapeHtml(g.name)}
          ${g.applied?.settingIds?.length ? `<span class="badge lime">${g.applied.settingIds.length}</span>` : g.installed ? '<span class="badge green">Installed</span>' : ''}
        </button>`).join('')}
    </div>`;
  return `
    ${sectionHead('Game profiles', 'Select competitive video settings to write directly to each game config file. Every modified setting is backed up and can be restored individually or in full.', actionsHtml)}
    ${filterTabs}
    <div class="game-grid">${visibleGames.map(gameCard).join('')}</div>
    ${state.games.some((game) => game.installed) ? '' : emptyState('gamepad', 'No supported game configs detected', 'Install and launch Fortnite, Counter-Strike 2, or Minecraft once so the game creates its configuration file, then click Re-check games.')}
  `;
}

function updateApplyButton(gameId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  const count = selectionFor(game).size;
  const button = document.querySelector(`[data-game-apply="${gameId}"]`);
  const label = document.querySelector(`[data-game-apply-label="${gameId}"]`);
  if (label) label.textContent = `Apply ${count} setting${count === 1 ? '' : 's'}`;
  if (button) button.disabled = !count || !game.installed || game.running;
}

async function applySelected(gameId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  const ids = Array.from(selectionFor(game));
  if (!ids.length) {
    toast('info', 'Nothing selected', 'Tick at least one setting to apply.');
    return;
  }
  const button = document.querySelector(`[data-game-apply="${gameId}"]`);
  if (button) button.disabled = true;
  try {
    const data = await api('/api/games/apply', { method: 'POST', body: { gameId, settingIds: ids } });
    replaceGame(data.game);
    state.history = null;
    toast('success', `${game.name} is tuned`, `${data.result.applied.length} setting${data.result.applied.length === 1 ? '' : 's'} applied. Original values are backed up and can be restored anytime.`);
  } catch (error) {
    toast('error', `Could not tune ${game.name}`, error.message);
  } finally {
    requestRender();
  }
}

async function restoreSingleSetting(gameId, settingId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  const setting = game.settings.find((item) => item.id === settingId);
  try {
    const data = await api('/api/games/revert', {
      method: 'POST',
      body: { gameId, settingIds: [settingId] },
    });
    replaceGame(data.game);
    state.history = null;
    toast('success', `${setting ? setting.label : 'Setting'} restored`, `Restored in ${game.name}.`);
  } catch (error) {
    toast('error', `Could not restore setting`, error.message);
  } finally {
    requestRender();
  }
}

function restoreGame(gameId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  openModal({
    title: `Restore ${game.name} settings?`,
    body: `<p>Nova will put back the original values it backed up (${game.applied?.settingIds.length || 0} setting${game.applied?.settingIds.length === 1 ? '' : 's'}). Anything else you changed in the game since then is kept.</p>`,
    confirmLabel: 'Restore original settings',
    onConfirm: async () => {
      const data = await api('/api/games/revert', { method: 'POST', body: { gameId } });
      replaceGame(data.game);
      state.gameSelections = state.gameSelections || {};
      delete state.gameSelections[gameId];
      state.history = null;
      toast('success', `${game.name} restored`, 'Your original settings are back.');
      requestRender();
    },
  });
}

function restoreAllGames() {
  const activeGames = (state.games || []).filter((g) => g.applied && g.applied.settingIds?.length);
  if (!activeGames.length) return;
  openModal({
    title: 'Restore all game settings?',
    body: `<p>Nova will restore original backed-up settings for <strong>${escapeHtml(activeGames.map((g) => g.name).join(', '))}</strong>.</p>`,
    confirmLabel: 'Restore all games',
    onConfirm: async () => {
      for (const game of activeGames) {
        const data = await api('/api/games/revert', { method: 'POST', body: { gameId: game.id } });
        replaceGame(data.game);
        if (state.gameSelections) delete state.gameSelections[game.id];
      }
      state.history = null;
      toast('success', 'All game settings restored', 'Every game is back to its original configuration.');
      requestRender();
    },
  });
}

export async function loadGames() {
  const data = await api('/api/games');
  state.games = data.games;
}

export function bindGames() {
  document.querySelectorAll('[data-game-filter]').forEach((button) => {
    button.addEventListener('click', () => {
      state.gameFilter = button.getAttribute('data-game-filter') || 'all';
      requestRender();
    });
  });
  document.querySelectorAll('[data-game-setting]').forEach((input) => {
    input.addEventListener('change', () => {
      const [gameId, settingId] = input.getAttribute('data-game-setting').split(':');
      const game = state.games?.find((item) => item.id === gameId);
      if (!game) return;
      const selected = selectionFor(game);
      if (input.checked) selected.add(settingId);
      else selected.delete(settingId);
      updateApplyButton(gameId);
    });
  });
  document.querySelectorAll('[data-game-pick]').forEach((button) => {
    button.addEventListener('click', () => {
      const [gameId, mode] = button.getAttribute('data-game-pick').split(':');
      const game = state.games?.find((item) => item.id === gameId);
      if (!game) return;
      const next = new Set();
      for (const setting of game.settings) {
        if (mode === 'all' || (mode === 'recommended' && setting.defaultOn && !setting.optimized)) next.add(setting.id);
      }
      state.gameSelections[gameId] = next;
      requestRender();
    });
  });
  document.querySelectorAll('[data-game-apply]').forEach((button) => {
    button.addEventListener('click', () => applySelected(button.getAttribute('data-game-apply')));
  });
  document.querySelectorAll('[data-game-restore]').forEach((button) => {
    button.addEventListener('click', () => restoreGame(button.getAttribute('data-game-restore')));
  });
  document.querySelectorAll('[data-game-restore-one]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      const [gameId, settingId] = button.getAttribute('data-game-restore-one').split(':');
      restoreSingleSetting(gameId, settingId);
    });
  });
  document.querySelectorAll('[data-action="restore-all-games"]').forEach((button) => {
    button.addEventListener('click', restoreAllGames);
  });
  document.querySelectorAll('[data-game-copy]').forEach((button) => {
    button.addEventListener('click', () => copyText(button.getAttribute('data-game-copy')));
  });
  document.querySelectorAll('[data-action="recheck-games"]').forEach((button) => {
    button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        await loadGames();
        toast('success', 'Games re-checked');
      } catch (error) {
        toast('error', 'Could not check games', error.message);
      }
      requestRender();
    });
  });
}
