import {
  state,
  icon,
  escapeHtml,
  toast,
  openModal,
  api,
  requestRender,
  copyText,
} from '../core.js';
import { sectionHead, impactBadge, emptyState } from '../ui.js';

function selectionFor(game) {
  state.gameSelections = state.gameSelections || {};
  if (!state.gameSelections[game.id]) {
    state.gameSelections[game.id] = new Set(
      game.settings.filter((setting) => setting.defaultOn && !setting.optimized).map((setting) => setting.id),
    );
  }
  return state.gameSelections[game.id];
}

function replaceGame(next) {
  if (!next || !Array.isArray(state.games)) return;
  state.games = state.games.map((game) => (game.id === next.id ? next : game));
}

function statusBadge(game) {
  if (game.running) return `<span class="badge amber">${icon('alert')} Running. Close it first</span>`;
  if (!game.installed) return '<span class="badge muted">Config not found</span>';
  if (game.applied) return `<span class="badge lime">${icon('check')} ${game.applied.settingIds.length} applied</span>`;
  return '<span class="badge green">Ready</span>';
}

function settingRow(game, setting, selected, locked) {
  const current = setting.current === null || setting.current === undefined ? 'not set' : setting.current;
  const values = setting.optimized
    ? `<span class="game-ok">${icon('check')} ${escapeHtml(setting.recommended)}</span>`
    : `<span class="game-from">${escapeHtml(current)}</span><span class="game-arrow">${icon('arrow')}</span><span class="game-to">${escapeHtml(setting.recommended)}</span>`;
  return `
    <label class="game-setting ${setting.optimized ? 'is-optimal' : ''} ${locked ? 'is-locked' : ''}">
      <input type="checkbox" data-game-setting="${escapeHtml(game.id)}:${escapeHtml(setting.id)}" ${selected.has(setting.id) ? 'checked' : ''} ${locked ? 'disabled' : ''}>
      <span class="game-check" aria-hidden="true">${icon('check', 12)}</span>
      <span class="game-setting-main">
        <strong>${escapeHtml(setting.label)} ${impactBadge(setting.impact)}</strong>
        <small>${escapeHtml(setting.description)}</small>
      </span>
      <span class="game-values mono">${values}</span>
    </label>`;
}

function gameCard(game) {
  const selected = selectionFor(game);
  const locked = !game.installed || game.running;
  const count = game.settings.filter((setting) => selected.has(setting.id)).length;
  const tips = (game.tips || []).map((tip) => `<li>${escapeHtml(tip)}</li>`).join('');
  return `
    <article class="card game-card" data-game="${escapeHtml(game.id)}">
      <header class="game-head">
        <div class="game-mark">${icon('gamepad', 22)}</div>
        <div class="game-title">
          <h3>${escapeHtml(game.name)}</h3>
          <p>${escapeHtml(game.tagline)}</p>
        </div>
        ${statusBadge(game)}
      </header>
      ${game.installed
        ? `<p class="game-file mono">${escapeHtml(game.fileLabel)}${game.files.length > 1 ? ` · ${game.files.length} Steam accounts` : ''}</p>`
        : `<p class="game-file game-missing">Nova looks for <span class="mono">${escapeHtml(game.expectedPath || game.fileLabel)}</span>. Launch ${escapeHtml(game.name)} once so it creates its config, then re-check.</p>`}
      <div class="game-tools">
        <span class="small muted">Choose what Nova changes</span>
        <span class="game-tool-links">
          <button class="link-button" type="button" data-game-pick="${escapeHtml(game.id)}:recommended" ${locked ? 'disabled' : ''}>Recommended</button>
          <button class="link-button" type="button" data-game-pick="${escapeHtml(game.id)}:all" ${locked ? 'disabled' : ''}>All</button>
          <button class="link-button" type="button" data-game-pick="${escapeHtml(game.id)}:none" ${locked ? 'disabled' : ''}>None</button>
        </span>
      </div>
      <div class="game-settings">
        ${game.settings.map((setting) => settingRow(game, setting, selected, locked)).join('')}
      </div>
      ${game.launchOptions ? `
        <div class="game-launch">
          <span class="small muted">Suggested Steam launch options</span>
          <code class="mono">${escapeHtml(game.launchOptions)}</code>
          <button class="button button-small" type="button" data-game-copy="${escapeHtml(game.launchOptions)}">${icon('copy')} Copy</button>
        </div>` : ''}
      <details class="game-tips">
        <summary>Before you apply</summary>
        <ul>${tips}</ul>
      </details>
      <footer class="game-foot">
        <button class="button button-primary" type="button" data-game-apply="${escapeHtml(game.id)}" ${locked || !count ? 'disabled' : ''}>${icon('zap')} <span data-game-apply-label="${escapeHtml(game.id)}">Apply ${count} setting${count === 1 ? '' : 's'}</span></button>
        ${game.applied ? `<button class="button" type="button" data-game-restore="${escapeHtml(game.id)}" ${game.running ? 'disabled' : ''}>${icon('undo')} Restore original</button>` : ''}
      </footer>
    </article>`;
}

export function renderGames() {
  if (!Array.isArray(state.games)) {
    return '<div class="page-loading"><div class="loading-orbit"></div><p>Looking for your games…</p></div>';
  }
  return `
    ${sectionHead('Game profiles', 'One click to the best-performance settings for the games you play. You choose which settings Nova touches.', `<button class="button button-small" type="button" data-action="recheck-games">${icon('refresh')} Re-check games</button>`)}
    <div class="callout" style="margin-bottom:14px">${icon('shield')}<div><strong>Edits the game's own config file only.</strong> No injection, no game files, no memory access, so it is anti-cheat safe. Nova saves a copy of each file, remembers every value it changes, and <em>Restore original</em> puts back only those values. Games must be closed first.</div></div>
    <div class="game-grid">${state.games.map(gameCard).join('')}</div>
    ${state.games.some((game) => game.installed) ? '' : emptyState('gamepad', 'No supported games found yet', 'Install and launch Fortnite, Counter-Strike 2 or Minecraft once, then press Re-check games.')}
    <p class="small muted" style="margin:14px 0 0">More games are coming in future updates. Settings are the same ones you can change in each game's video menu, just applied in one step.</p>
  `;
}

function updateApplyButton(gameId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  const count = selectionFor(game).size;
  const button = document.querySelector(`[data-game-apply="${gameId}"]`);
  const label = document.querySelector(`[data-game-apply-label="${gameId}"]`);
  if (label) label.textContent = `Apply ${count} setting${count === 1 ? '' : 's'}`;
  if (button) button.disabled = !count || !game.installed || game.running;
}

async function applySelected(gameId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  const ids = Array.from(selectionFor(game));
  if (!ids.length) {
    toast('info', 'Nothing selected', 'Tick at least one setting to apply.');
    return;
  }
  const button = document.querySelector(`[data-game-apply="${gameId}"]`);
  if (button) button.disabled = true;
  try {
    const data = await api('/api/games/apply', { method: 'POST', body: { gameId, settingIds: ids } });
    replaceGame(data.game);
    state.history = null;
    toast('success', `${game.name} is tuned`, `${data.result.applied.length} setting${data.result.applied.length === 1 ? '' : 's'} applied. Start the game to feel it.`);
  } catch (error) {
    toast('error', `Could not tune ${game.name}`, error.message);
  } finally {
    requestRender();
  }
}

function restoreGame(gameId) {
  const game = state.games?.find((item) => item.id === gameId);
  if (!game) return;
  openModal({
    title: `Restore ${game.name} settings?`,
    body: `<p>Nova will put back the values it changed (${game.applied?.settingIds.length || 0} setting${game.applied?.settingIds.length === 1 ? '' : 's'}). Anything else you changed in the game since then is kept.</p>`,
    confirmLabel: 'Restore original',
    onConfirm: async () => {
      const data = await api('/api/games/revert', { method: 'POST', body: { gameId } });
      replaceGame(data.game);
      state.gameSelections = state.gameSelections || {};
      delete state.gameSelections[gameId];
      state.history = null;
      toast('success', `${game.name} restored`, 'Your original settings are back.');
      requestRender();
    },
  });
}

export async function loadGames() {
  const data = await api('/api/games');
  state.games = data.games;
}

export function bindGames() {
  document.querySelectorAll('[data-game-setting]').forEach((input) => {
    input.addEventListener('change', () => {
      const [gameId, settingId] = input.getAttribute('data-game-setting').split(':');
      const game = state.games?.find((item) => item.id === gameId);
      if (!game) return;
      const selected = selectionFor(game);
      if (input.checked) selected.add(settingId);
      else selected.delete(settingId);
      updateApplyButton(gameId);
    });
  });
  document.querySelectorAll('[data-game-pick]').forEach((button) => {
    button.addEventListener('click', () => {
      const [gameId, mode] = button.getAttribute('data-game-pick').split(':');
      const game = state.games?.find((item) => item.id === gameId);
      if (!game) return;
      const next = new Set();
      for (const setting of game.settings) {
        if (mode === 'all' || (mode === 'recommended' && setting.defaultOn && !setting.optimized)) next.add(setting.id);
      }
      state.gameSelections[gameId] = next;
      requestRender();
    });
  });
  document.querySelectorAll('[data-game-apply]').forEach((button) => {
    button.addEventListener('click', () => applySelected(button.getAttribute('data-game-apply')));
  });
  document.querySelectorAll('[data-game-restore]').forEach((button) => {
    button.addEventListener('click', () => restoreGame(button.getAttribute('data-game-restore')));
  });
  document.querySelectorAll('[data-game-copy]').forEach((button) => {
    button.addEventListener('click', () => copyText(button.getAttribute('data-game-copy')));
  });
  document.querySelectorAll('[data-action="recheck-games"]').forEach((button) => {
    button.addEventListener('click', async () => {
      button.disabled = true;
      try {
        await loadGames();
        toast('success', 'Games re-checked');
      } catch (error) {
        toast('error', 'Could not check games', error.message);
      }
      requestRender();
    });
  });
}

