# Nova Optimize

A free, local-first Windows gaming performance and latency suite. No account, no ads, no telemetry, no premium tier.

Nova scans your PC, explains what is actually worth changing, applies only the changes you select, backs up every value, and lets you undo everything.

![Nova Optimize](public/assets/logo.svg)

## What it does

- **Readiness scan** with an honest score, category breakdown and prioritized findings.
- **Safe tweaks**: Windows Game Mode, background game recording, hardware-accelerated GPU scheduling, windowed game optimizations, background apps, transparency, a dedicated Nova Gaming power plan and network adapter power saving.
- **Advanced controls** (opt-in): Games task priority, multimedia network throttling, system responsiveness, mouse acceleration and TCP acknowledgement delay. These are marked advanced because the effect varies by game and system. Every one is reversible.
- **Network lab**: game-route latency tests over ICMP or TCP, jitter and packet loss, custom targets, DNS benchmark, DNS provider switching, DNS cache flush, and a speed test with a bufferbloat grade.
- **Cleanup**: scans known temporary-file locations by category and deletes only the categories you select. It does not touch Downloads, Documents, Desktop or personal files.
- **Startup manager**: lists startup apps, disables and re-enables them, protects security entries, and keeps a backup of file-based startup items.
- **Activity and reports**: a local audit trail, active changes, one-click undo all, and a JSON report you can save locally.
- **Settings**: administrator elevation, restore point creation, reduced motion, compact layout, Advanced page visibility, ping sample count and the data folder.

## Safety promises

- Never disables Windows Security, Microsoft Defender or Windows Firewall.
- Never installs drivers and never overclocks hardware.
- Never deletes personal files. Cleanup only touches known temp and cache locations, and only after you confirm.
- Every system change is applied only after you select it. Nova records a backup first; Undo restores the previous value.
- No fake FPS claims. Some tweaks have zero effect on some systems, and Nova says so in the description.
- Changing DNS does not lower in-game ping. It can improve website and app lookups. Nova labels it that way.
- No telemetry, no account and no cloud sync. The server listens on `127.0.0.1` only.

## Requirements

- Windows 10 or Windows 11.
- [Node.js](https://nodejs.org/) 18 or newer (LTS recommended).
- Microsoft Edge for the app-style window. Without Edge, Nova opens in your default browser.
- Administrator rights are optional for browsing and user-level fixes. System-wide fixes, DNS changes and system cleanup ask before elevating.

## Start Nova

1. Install Node.js LTS.
2. Put the Nova folder anywhere you like. Avoid `Program Files` if you want to launch without a UAC prompt.
3. Double-click **`NovaOptimize.vbs`** for a silent launch, or **`Start Nova.bat`** if you want to see server logs.
4. Optional: right-click **`Create Shortcut.ps1`** and choose **Run with PowerShell** to add a Desktop shortcut with the Nova icon.

The first scan reads hardware, Windows settings and startup entries. Nothing is changed during a scan.

> If Windows SmartScreen warns about the unsigned launcher, choose **More info** then **Run anyway**, or use `Start Nova.bat`. Nova is plain source code with no install step and no bundled binaries.

## How it works

- `server/server.js` starts a small HTTP server on `127.0.0.1:4318`.
- The interface is plain HTML, CSS and JavaScript served from `public/`.
- Windows operations run through `server/scripts/bridge.ps1`. Requests are base64-encoded JSON, so user input is never interpolated into a PowerShell command line.
- The server requires a random per-session token, validates the Host and Origin headers, and rejects cross-origin requests.
- State, backups, startup backups and the activity log live in `data/state.json` and `data/startup-backup/`.
- There are no npm dependencies and no build step.

## Using Nova

1. Run a scan and read the findings. The score is a configuration score, not a benchmark.
2. Apply one change at a time from **Optimize**, then test your game. If it does not help, use **Undo**.
3. Use **Network lab** to measure route latency, jitter, loss, DNS lookup speed and bufferbloat. Measurement is read-only; DNS apply and reset are explicit actions.
4. Use **Cleanup** and **Startup** deliberately. Both list what they will change before doing it.
5. Check **Activity** to see every change and its undo button. Export a report if you want a local record.

## What Nova will not do

Nova is deliberately not a "one-click FPS booster". It will not:

- disable Windows Security, Defender or the firewall;
- install or silently update drivers;
- overclock the CPU or GPU;
- run RAM cleaners or registry cleaners;
- delete personal files;
- install browser toolbars, bundled software or background services;
- claim that a registry tweak guarantees more FPS.

Hardware, the game engine, the server you connect to and your network path usually matter far more than any software tweak. Nova tells you when that is the case.

## Troubleshooting

- **"Nova needs Node.js 18 or newer"**: install Node.js LTS, open a new terminal and check `node -v`.
- **Port 4318 is already in use**: start with another port, for example `set NOVA_PORT=4319 && npm start` in Command Prompt, or `$env:NOVA_PORT=4319; npm start` in PowerShell.
- **The app window did not open**: open <http://127.0.0.1:4318> in a browser.
- **PowerShell is blocked**: the bridge uses `-ExecutionPolicy Bypass` for its own process only. It does not change your system policy. If AppLocker or WDAC blocks scripts, allow the Nova folder.
- **Restore point fails**: System Restore may be disabled. Enable it in Windows, then try again.
- **Antivirus flags the VBS launcher**: it is an unsigned script. Use `Start Nova.bat` or read `NovaOptimize.vbs`; it only locates Node and starts the local server.
- **The interface looks stale after an edit**: Nova sends `Cache-Control: no-store`, but a hard refresh with `Ctrl+F5` is still a good first step.
- **Reset Nova's app memory**: quit Nova, then delete the `data` folder. This removes backups and the activity log. Undo any active Windows changes first.

## Development

```bat
npm start        :: start the local server
npm run dev      :: start with development logging
npm test         :: run the node:test suites
npm run check    :: syntax-check the main server and frontend entrypoints
```

There is no `npm install` step. Tests cover input validation, score calculation, action backups and reverts, network grading and module loading.

### Project layout

```text
public/               UI shell, styles and page modules
server/server.js      local HTTP server, API routes, auth and elevation
server/lib/           actions, analysis, network, system, store, validation, PowerShell bridge
server/scripts/       bridge.ps1 with all Windows operations
test/                 node:test suites and fixtures
data/                 local state, backups and activity (gitignored; created on first run)
Start Nova.bat        console launcher with Node checks
NovaOptimize.vbs      silent launcher
Create Shortcut.ps1   optional Desktop shortcut installer
```

## Privacy

Nova has no analytics, no telemetry, no account system and no update pings. Network requests are made only when you start a measurement:

- Cloudflare speed-test endpoints during a speed test;
- DNS queries to the providers being benchmarked;
- game or service hostnames during route tests.

Reports are generated locally and never uploaded. Review a report before sharing it, because it contains hardware names and local network results.

## License

MIT. See [LICENSE](LICENSE).
