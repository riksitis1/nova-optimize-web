import {
  state,
  icon,
  escapeHtml,
  toast,
  openModal,
  elevate,
  api,
  requestRender,
} from '../core.js';
import { emptyState, sectionHead } from '../ui.js';

function impactBadge(impact) {
  if (impact === 'high') return '<span class="badge amber">Likely high impact</span>';
  if (impact === 'low') return '<span class="badge muted">Likely low impact</span>';
  return '<span class="badge cyan">Likely medium</span>';
}

function initials(name) {
  return String(name || '?').replace(/[^a-z0-9]/gi, ' ').trim().split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase() || '?';
}

function startupRow(item) {
  const needsAdmin = item.requiresAdmin || (item.type === 'registry' && item.hive === 'HKLM');
  const locked = item.protected || (!state.snapshot?.admin && needsAdmin);
  return `
    <div class="startup-row ${item.enabled ? '' : 'disabled'}" data-startup-name="${escapeHtml(`${item.name} ${item.command}`.toLowerCase())}">
      <div class="startup-avatar">${escapeHtml(initials(item.name))}</div>
      <div class="startup-info">
        <strong>${escapeHtml(item.name)} ${item.protected ? '<span class="badge muted">Protected</span>' : ''} ${!state.snapshot?.admin && needsAdmin ? '<span class="badge muted">Admin</span>' : ''} ${item.enabled ? '' : '<span class="badge amber">Disabled by Nova</span>'}</strong>
        <small title="${escapeHtml(item.command)}">${escapeHtml(item.source)} · ${escapeHtml(item.command)}</small>
      </div>
      <div class="chip-row" style="flex:0 0 auto">${impactBadge(item.impact)}</div>
      <button class="switch ${item.enabled ? 'on' : ''}" type="button" role="switch" aria-checked="${item.enabled}" data-startup-toggle="${escapeHtml(item.id)}" data-enabled="${item.enabled ? 'true' : 'false'}" aria-label="${item.enabled ? 'Disable' : 'Enable'} ${escapeHtml(item.name)}" ${locked ? 'disabled' : ''}></button>
    </div>`;
}

export function renderStartup() {
  if (!state.startup) {
    return '<div class="page-loading"><div class="loading-orbit"></div><p>Reading startup entries…</p></div>';
  }
  const filter = state.startupFilter || 'all';
  const query = (state.startupQuery || '').toLowerCase();
  const all = [...(state.startup.active || []), ...(state.startup.disabled || [])];
  const filtered = all.filter((item) => {
    if (filter === 'active' && !item.enabled) return false;
    if (filter === 'disabled' && item.enabled) return false;
    if (filter === 'protected' && !item.protected) return false;
    if (query && !`${item.name} ${item.command} ${item.source}`.toLowerCase().includes(query)) return false;
    return true;
  });
  return `
    ${sectionHead('Startup', 'Fewer startup apps means a faster login and less background work.', `<button class="button button-small" type="button" data-action="startup-refresh">${icon('refresh')} Refresh</button>`)}
    ${!state.snapshot?.admin ? `<div class="callout warn" style="margin-bottom:14px">${icon('lock')}<div><strong>System-wide startup entries need admin.</strong> User startup entries can be managed now. <button class="button button-small" type="button" data-action="elevate" style="margin-left:8px">Restart as admin</button></div></div>` : ''}
    <div class="grid-3" style="margin-bottom:16px">
      <div class="network-stat"><span>Active</span><strong>${state.startup.activeCount}</strong><small>Programs launch at sign-in</small></div>
      <div class="network-stat"><span>Disabled by Nova</span><strong>${state.startup.disabledCount}</strong><small>Restorable from this page</small></div>
      <div class="network-stat"><span>Protected</span><strong>${state.startup.protectedCount}</strong><small>Security and core entries</small></div>
    </div>
    <div class="card card-pad">
      <div class="startup-toolbar">
        <div class="tabs">
          ${['all', 'active', 'disabled', 'protected'].map((value) => `<button class="tab ${filter === value ? 'active' : ''}" type="button" data-startup-filter="${value}">${value[0].toUpperCase() + value.slice(1)}</button>`).join('')}
        </div>
        <input class="input" id="startup-search" placeholder="Search startup apps…" value="${escapeHtml(state.startupQuery || '')}" autocomplete="off">
      </div>
      ${filtered.length ? `<div class="startup-list">${filtered.map(startupRow).join('')}</div>` : emptyState('search', 'No matching startup apps', 'Try a different search or filter.')}
    </div>
    <div class="callout" style="margin-top:14px">${icon('info')}<div><strong>Impact labels are estimates.</strong> They are based on the app name and command, not a live benchmark. Disabling an app only stops it from launching at sign-in; it does not uninstall it. Security, antivirus, firewall and core input/audio entries matching Nova's safety list are protected.</div></div>
  `;
}

async function performStartupToggle(item, currentlyEnabled, button) {
  if (button) button.disabled = true;
  try {
    const data = await api('/api/startup/toggle', {
      method: 'POST',
      body: { id: item.id, enabled: !currentlyEnabled },
    });
    state.startup = data.startup;
    state.history = null;
    toast('success', currentlyEnabled ? 'Startup app disabled' : 'Startup app re-enabled', item.name);
    requestRender();
  } catch (error) {
    toast('error', 'Could not change startup app', error.message);
    if (button) button.disabled = false;
  }
}

async function toggleStartup(button) {
  const id = button.getAttribute('data-startup-toggle');
  const currentlyEnabled = button.getAttribute('data-enabled') === 'true';
  const item = [...(state.startup?.active || []), ...(state.startup?.disabled || [])].find((entry) => entry.id === id);
  if (!item) return;
  if (item.protected) {
    toast('warn', 'Protected entry', 'Nova will not disable security or core system startup entries.');
    return;
  }
  const needsAdmin = item.requiresAdmin || (item.type === 'registry' && item.hive === 'HKLM');
  if (!state.snapshot?.admin && needsAdmin) {
    openModal({
      title: 'Administrator access needed',
      body: '<p>This is a system-wide startup entry. Restart Nova with administrator rights to change it.</p>',
      confirmLabel: 'Restart as administrator',
      onConfirm: elevate,
    });
    return;
  }
  if (currentlyEnabled) {
    openModal({
      title: `Disable ${item.name} at startup?`,
      body: `<p>This stops <strong>${escapeHtml(item.name)}</strong> from launching automatically when you sign in. It does not uninstall the program.</p><ul class="modal-list"><li>Source: ${escapeHtml(item.source)}</li><li>Command: <span class="mono">${escapeHtml(item.command)}</span></li><li>Nova backs up this entry so you can re-enable it anytime.</li></ul>`,
      confirmLabel: 'Disable at startup',
      onConfirm: () => performStartupToggle(item, true, button),
    });
    return;
  }
  await performStartupToggle(item, false, button);
}

async function refreshStartup(button) {
  if (button) {
    button.disabled = true;
    button.innerHTML = `${icon('refresh')} Reading…`;
  }
  try {
    const data = await api('/api/startup');
    state.startup = data.startup;
    toast('success', 'Startup list refreshed');
    requestRender();
  } catch (error) {
    toast('error', 'Could not read startup apps', error.message);
    if (button) {
      button.disabled = false;
      button.innerHTML = `${icon('refresh')} Refresh`;
    }
  }
}

export function bindStartup() {
  document.querySelectorAll('[data-startup-toggle]').forEach((button) => {
    button.addEventListener('click', () => toggleStartup(button));
  });
  document.querySelectorAll('[data-startup-filter]').forEach((button) => {
    button.addEventListener('click', () => {
      state.startupFilter = button.getAttribute('data-startup-filter');
      requestRender();
    });
  });
  document.querySelectorAll('[data-action="startup-refresh"]').forEach((button) => {
    button.addEventListener('click', () => refreshStartup(button));
  });
  document.querySelectorAll('[data-action="elevate"]').forEach((button) => {
    button.addEventListener('click', elevate);
  });
  const search = document.getElementById('startup-search');
  if (search) {
    search.addEventListener('input', () => {
      state.startupQuery = search.value;
      const query = search.value.toLowerCase();
      document.querySelectorAll('[data-startup-name]').forEach((row) => {
        row.style.display = row.getAttribute('data-startup-name').includes(query) ? '' : 'none';
      });
    });
  }
}
