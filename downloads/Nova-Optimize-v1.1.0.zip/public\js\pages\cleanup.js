import {
  state,
  icon,
  escapeHtml,
  formatBytes,
  toast,
  openModal,
  elevate,
  api,
  requestRender,
} from '../core.js';
import { emptyState, sectionHead } from '../ui.js';

function riskBadge(risk) {
  if (risk === 'caution') return '<span class="badge amber">Caution</span>';
  return '<span class="badge green">Safe</span>';
}

function initializeSelection() {
  if (!state.cleanup || state.cleanupInitialized) return;
  state.cleanupSelected = new Set(
    state.cleanup
      .filter((category) => category.risk === 'safe' && category.bytes > 0 && (!category.requiresAdmin || state.snapshot?.admin))
      .map((category) => category.id),
  );
  state.cleanupInitialized = true;
}

function rowHtml(category) {
  const checked = state.cleanupSelected.has(category.id);
  const locked = category.requiresAdmin && !state.snapshot?.admin;
  return `
    <div class="cleanup-row ${checked ? 'checked' : ''} ${locked ? 'locked' : ''}" data-cleanup-row="${escapeHtml(category.id)}">
      <button class="check ${checked ? 'checked' : ''}" type="button" data-cleanup-toggle="${escapeHtml(category.id)}" ${locked ? 'disabled' : ''} aria-pressed="${checked}" aria-label="Select ${escapeHtml(category.label)}">${icon('check')}</button>
      <div class="target-avatar" style="color:${category.risk === 'caution' ? 'var(--amber)' : 'var(--lime)'}">${icon(category.recycleBin ? 'trash' : category.id === 'browser-cache' ? 'globe' : category.id === 'shader-cache' ? 'gpu' : 'folder')}</div>
      <div class="cleanup-info"><strong>${escapeHtml(category.label)} ${riskBadge(category.risk)} ${locked ? '<span class="badge muted">Admin</span>' : ''}</strong><small>${escapeHtml(category.description)}</small></div>
      <div class="cleanup-size"><strong>${formatBytes(category.bytes)}</strong><small>${category.files.toLocaleString()} files</small></div>
    </div>`;
}

function resultsHtml() {
  const result = state.cleanupResult;
  if (!result) return '';
  const freed = result.freed || 0;
  const failed = (result.results || []).filter((item) => item.skipped || (item.errors && item.errors.length));
  return `
    <div class="callout ${failed.length ? 'warn' : ''}" style="margin-top:14px">
      ${icon(failed.length ? 'alert' : 'check')}
      <div><strong>${formatBytes(freed)} freed.</strong> ${result.results?.length || 0} categories processed.${failed.length ? ` ${failed.length} category${failed.length === 1 ? '' : 'ies'} skipped or partially blocked.` : ''}
      ${failed.length ? `<div class="small" style="margin-top:5px">${failed.map((item) => escapeHtml(item.reason || item.errors?.[0] || item.id)).join(' · ')}</div>` : ''}</div>
    </div>`;
}

export function renderCleanup() {
  if (!state.cleanup) {
    return '<div class="page-loading"><div class="loading-orbit"></div><p>Measuring temporary files…</p></div>';
  }
  initializeSelection();
  const categories = state.cleanup;
  const selected = categories.filter((category) => state.cleanupSelected.has(category.id));
  const selectedSize = selected.reduce((sum, category) => sum + (Number(category.bytes) || 0), 0);
  const selectedFiles = selected.reduce((sum, category) => sum + (Number(category.files) || 0), 0);
  const totalSize = categories.reduce((sum, category) => sum + (Number(category.bytes) || 0), 0);
  const admin = state.snapshot?.admin === true;
  return `
    ${sectionHead('Cleanup', 'Reclaim space without touching personal files.', `<button class="button button-small" type="button" data-action="cleanup-scan">${icon('refresh')} Scan again</button>`)}
    ${!admin ? `<div class="callout warn" style="margin-bottom:14px">${icon('lock')}<div><strong>Some categories need administrator access.</strong> Windows temp and error reports are locked until Nova is elevated. <button class="button button-small" type="button" data-action="elevate" style="margin-left:8px">Restart as admin</button></div></div>` : ''}
    <div class="grid-3" style="margin-bottom:16px">
      <div class="network-stat"><span>Found</span><strong>${formatBytes(totalSize)}</strong><small>Across ${categories.length} categories</small></div>
      <div class="network-stat"><span>Selected</span><strong>${formatBytes(selectedSize)}</strong><small>${selectedFiles.toLocaleString()} files selected</small></div>
      <div class="network-stat"><span>Scope</span><strong>Known caches</strong><small>Documents & Desktop are never scanned</small></div>
    </div>
    <div class="card card-pad">
      <div class="card-header"><div><h2>Cleanup categories</h2><p>Temp and cache data only. Unlike registry tweaks, deleted files are not backed up.</p></div><div class="card-actions"><span class="badge muted">${categories.length} categories</span></div></div>
      ${categories.length ? `<div class="cleanup-list">${categories.map(rowHtml).join('')}</div>` : emptyState('check', 'Nothing to clean', 'Nova did not find measurable temp or cache data.')}
      <div class="cleanup-total">
        <div><strong>${formatBytes(selectedSize)}</strong><span> ready to free</span></div>
        <button class="button button-primary" type="button" data-action="cleanup-run" ${selected.length ? '' : 'disabled'}>${icon('broom')} Clean selected</button>
      </div>
      ${resultsHtml()}
    </div>
    <div class="callout" style="margin-top:14px">${icon('info')}<div><strong>What Nova deletes:</strong> user temp files, Windows temp files, crash dumps, error reports, GPU shader caches, browser caches (Chrome, Edge, Brave, Vivaldi, Firefox) and optionally the Recycle Bin. Browser caches require the browser to be closed. Shader caches rebuild automatically and may cause a short first-run stutter.</div></div>
    <p class="small muted" style="margin-top:20px;line-height:1.6">Nova does not use “registry cleaners”, does not delete prefetch, does not disable Windows Update, and never scans your Documents, Saves, Screenshots, Desktop or Downloads folders. Emptying the Recycle Bin is off by default and permanent.</p>
  `;
}

async function scanCleanup(button) {
  if (button) {
    button.disabled = true;
    button.innerHTML = `${icon('refresh')} Scanning…`;
  }
  try {
    const data = await api('/api/cleanup/scan');
    state.cleanup = data.categories;
    state.cleanupInitialized = false;
    state.cleanupResult = null;
    state.cleanupSelected = new Set();
    toast('success', 'Cleanup scan complete');
    requestRender();
  } catch (error) {
    toast('error', 'Cleanup scan failed', error.message);
    if (button) {
      button.disabled = false;
      button.innerHTML = `${icon('refresh')} Scan again`;
    }
  }
}

function runCleanup() {
  const selected = (state.cleanup || []).filter((category) => state.cleanupSelected.has(category.id));
  if (!selected.length) {
    toast('warn', 'Nothing selected', 'Choose at least one category to clean.');
    return;
  }
  if (selected.some((category) => category.requiresAdmin) && !state.snapshot?.admin) {
    openModal({
      title: 'Administrator access needed',
      body: '<p>One or more selected categories require administrator rights. Restart Nova with administrator access and try again.</p>',
      confirmLabel: 'Restart as administrator',
      onConfirm: elevate,
    });
    return;
  }
  const recycle = selected.some((category) => category.recycleBin);
  openModal({
    title: `Free ${formatBytes(selected.reduce((sum, category) => sum + (Number(category.bytes) || 0), 0))}?`,
    body: `<p>Nova will remove temp and cache data from the selected categories. Files in use are skipped. This cannot be undone.</p><ul class="modal-list">${selected.map((category) => `<li>${escapeHtml(category.label)} — ${formatBytes(category.bytes)}</li>`).join('')}</ul>${recycle ? '<p class="small" style="margin-top:10px;color:var(--amber)">The Recycle Bin will be emptied. Deleted files cannot be recovered.</p>' : ''}`,
    confirmLabel: 'Clean now',
    danger: true,
    onConfirm: async () => {
      const data = await api('/api/cleanup/run', {
        method: 'POST',
        body: { ids: selected.map((category) => category.id) },
      });
      state.cleanupResult = data;
      const fresh = await api('/api/cleanup/scan');
      state.cleanup = fresh.categories;
      state.cleanupInitialized = false;
      state.cleanupSelected = new Set();
      state.history = null;
      toast('success', 'Cleanup complete', `${formatBytes(data.freed || 0)} freed.`);
      requestRender();
    },
  });
}

function toggleCategory(id) {
  const category = (state.cleanup || []).find((item) => item.id === id);
  if (!category) return;
  if (category.requiresAdmin && !state.snapshot?.admin) return;
  if (state.cleanupSelected.has(id)) state.cleanupSelected.delete(id);
  else state.cleanupSelected.add(id);
  requestRender();
}

export function bindCleanup() {
  document.querySelectorAll('[data-cleanup-toggle]').forEach((button) => {
    button.addEventListener('click', (event) => {
      event.stopPropagation();
      toggleCategory(button.getAttribute('data-cleanup-toggle'));
    });
  });
  document.querySelectorAll('[data-cleanup-row]').forEach((row) => {
    row.addEventListener('click', (event) => {
      if (event.target.closest('button')) return;
      toggleCategory(row.getAttribute('data-cleanup-row'));
    });
  });
  document.querySelectorAll('[data-action="cleanup-scan"]').forEach((button) => {
    button.addEventListener('click', () => scanCleanup(button));
  });
  document.querySelectorAll('[data-action="cleanup-run"]').forEach((button) => {
    button.addEventListener('click', runCleanup);
  });
  document.querySelectorAll('[data-action="elevate"]').forEach((button) => {
    button.addEventListener('click', elevate);
  });
}
